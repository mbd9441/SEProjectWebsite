package com.bizcloud.infokiosk;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;

import com.bizcloud.infokiosk.presenter.CardPresenter;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.leanback.app.VerticalGridSupportFragment;
import androidx.leanback.widget.ArrayObjectAdapter;
import androidx.leanback.widget.FocusHighlight;
import androidx.leanback.widget.VerticalGridPresenter;

import static com.bizcloud.infokiosk.CardsActivity.LOG_TAG;

public class VerticalGridFragment extends VerticalGridSupportFragment {

    private static final String TAG = VerticalGridFragment.class.getSimpleName();
    private static final int NUM_COLUMNS = 5;
    private String deviceID ;
    private ArrayObjectAdapter mAdapter;
    private ArrayList<Card> cards = new ArrayList<>();
    private String topic;
    private Drawable qr;
    private ArrayList<String> cardsInfo = new ArrayList<>();
    private String androidId = "";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);

        //setTitle("Info Kiosk");
        Log.d(TAG, "This is the " + TAG);
        Intent intent = getActivity().getIntent();
        this.androidId = intent.getStringExtra(VerticalGridActivity.ANDROID_ID);
//        Log.d(LOG_TAG, androidId);
        String url = "https://lvtsme4ili.execute-api.us-east-1.amazonaws.com/master/devices/instance/"+androidId;
        try {
            int SDK_INT = android.os.Build.VERSION.SDK_INT;
            JSONObject json = null;
            if (SDK_INT > 8) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                        .permitAll().build();
                StrictMode.setThreadPolicy(policy);
                //your codes here
                json = readJsonFromUrl(url);

            }
            //= readJsonFromUrl(url);
            Log.d(LOG_TAG, "json obect" + json.toString());

            JSONObject array = json.getJSONObject("message");
            deviceID = Integer.toString((int)array.get("device_id"));
            topic = array.getString("topic_name");
        }
        catch (IOException e){
            Log.e("InfoKiosk", "unexpected IO exception", e);
            // Do something to recover ... or kill the app.
        }
        catch (JSONException j){
            Log.e("InfoKiosk", "unexpected JSON exception", j);
        }
        generateQR();
        setBadgeDrawable(qr);
        updateCards();
    }

    private void generateQR() {
        // https://gist.github.com/adrianoluis/fa9374d7f2f8ca1115b00cc83cd7aacd
        String link = "http://d1isz88ubcguwa.cloudfront.net/content/request/" + topic + "/";
        BitMatrix result;

        try {
            result = new MultiFormatWriter().encode(link, BarcodeFormat.QR_CODE, 150, 150, null);
        } catch (IllegalArgumentException | WriterException e) {
            // Unsupported format
            return ;
        }

        final int w = result.getWidth();
        final int h = result.getHeight();
        final int[] pixels = new int[w * h];

        for (int y = 0; y < h; y++) {
            final int offset = y * w;
            for (int x = 0; x < w; x++) {
                pixels[offset + x] = result.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }

        final Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, 150, 0, 0, w, h);

        Drawable d = new BitmapDrawable(bitmap);
        qr = d;
    }

    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    private static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        } finally {
            is.close();
        }
    }

    private void generateCards(String url){
        // calls a url and generates cards
        try {
            JSONObject json = readJsonFromUrl(url);
            JSONArray array = json.getJSONArray("Cards");
            for(int i = 0; i < array.length(); i++){
                JSONObject current = array.getJSONObject(i);
                String title = (String) current.get("Title");
                String message = (String) current.get("Description");
                String link = (String) current.get("Link");
                cards.add(new Card(title,message,link));
            }
        }
        catch (IOException e){
            Log.e("InfoKiosk", "unexpected IO exception", e);
            // Do something to recover ... or kill the app.
        }
        catch (JSONException j){
            Log.e("InfoKiosk", "unexpected JSON exception", j);
        }

    }

    public void reload(){
        Fragment currentFragment = getFragmentManager().findFragmentById(R.id.vertical_grid_fragment);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.detach(currentFragment);
        fragmentTransaction.attach(currentFragment);
        fragmentTransaction.commit();
        updateCards();
    }

    private void updateCards(){

        String url = "https://lvtsme4ili.execute-api.us-east-1.amazonaws.com/master/devices/content/"+ deviceID;
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //your codes here
            generateCards(url);
        }


            VerticalGridPresenter gridPresenter = new VerticalGridPresenter(FocusHighlight.ZOOM_FACTOR_LARGE, false);
            gridPresenter.setNumberOfColumns(NUM_COLUMNS);
            setGridPresenter(gridPresenter);
            gridPresenter.setShadowEnabled(false);


            mAdapter = new ArrayObjectAdapter(new CardPresenter());
            //mAdapter = new ArrayObjectAdapter(new TextCardPresenter(getActivity()));
            for (Card card : cards) {
                mAdapter.add(card);
            }
            setAdapter(mAdapter);
        }
}

