package com.bizcloud.infokiosk;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.leanback.widget.BaseCardView;

public class CustomImageCardView extends BaseCardView {

    private ImageView mImageView;
    private ViewGroup mInfoArea;
    private TextView mTitleView;
    private TextView mContentView;
    private ImageView mBadgeImage;

    public CustomImageCardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        buildImageCardView();
    }

    public CustomImageCardView(Context context) {
        this(context, null);
    }

    public CustomImageCardView(Context context, AttributeSet attrs) {
        this(context, attrs, R.attr.imageCardViewStyle);
    }


    private void buildImageCardView() {
        // Make sure the ImageCardView is focusable.
        setFocusable(true);
        setFocusableInTouchMode(true);

        LayoutInflater inflater = LayoutInflater.from(getContext());
        inflater.inflate(R.layout.custom_view_card, this);

        mImageView = findViewById(R.id.main_image);
        if (mImageView.getDrawable() == null) {
            mImageView.setVisibility(View.INVISIBLE);
        }

        mInfoArea = findViewById(R.id.info_field);

        // Create children
        mTitleView = findViewById(R.id.title_text);

        mContentView = findViewById(R.id.content_text);

        mBadgeImage = findViewById(R.id.extra_badge);
    }

    /**
     * Sets the title text.
     */
    public void setTitleText(CharSequence text) {
        if (mTitleView == null) {
            return;
        }
        mTitleView.setText(text);
    }

    /**
     *  Sets the color of the title text.
     */
    public void setTitleColor(int color) {
        if (mTitleView == null) {
            return;
        }
        mTitleView.setTextColor(getResources().getColor(color));
    }

    /**
     * Sets the color of the content text.
     */
    public void setContentColor(int color) {
        if (mContentView == null) {
            return;
        }
        mContentView.setTextColor(getResources().getColor(color));
    }

    /**
     * Sets the content text.
     */
    public void setContentText(CharSequence text) {
        if (mContentView == null) {
            return;
        }
        mContentView.setText(text);
    }


    /**
     * Sets the image drawable with optional fade-in animation.
     */
    public void setMainImage(Drawable drawable) {
        if (mImageView == null) {
            return;
        }

        mImageView.setImageDrawable(drawable);
    }

    /**
     * Sets the layout dimensions of the ImageView.
     */
    public void setMainImageDimensions(int width, int height) {
        ViewGroup.LayoutParams lp = mImageView.getLayoutParams();
        lp.width = width;
        lp.height = height;
        mImageView.setLayoutParams(lp);
    }


    /**
     * Sets the badge image drawable.
     */
    public void setBadgeImage(Drawable drawable) {
        if (mBadgeImage == null) {
            return;
        }
        mBadgeImage.setImageDrawable(drawable);
        if (drawable != null) {
            mBadgeImage.setVisibility(View.VISIBLE);
        } else {
            mBadgeImage.setVisibility(View.GONE);
        }
    }

}
