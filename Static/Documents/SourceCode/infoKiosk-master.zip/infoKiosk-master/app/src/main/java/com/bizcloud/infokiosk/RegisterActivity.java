package com.bizcloud.infokiosk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class RegisterActivity extends Activity {

    private TextView android_id;

    public static final String CLIENT_ID = "com.bizcloud.infokiosk.id.CLIENT";

    public static final String ANDROID_ID = "com.bizcloud.infokiosk.id.ANDROID";

    private EditText client_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        String androidId;

        if(Build.FINGERPRINT.contains("generic")){
            androidId = "fakeinstance_id";
        }
        else{
            TelephonyManager manager =
                    (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
            androidId = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);
        }
        android_id = findViewById(R.id.text_mac_address);
        android_id.setText(androidId);

        client_id = findViewById(R.id.edittext_client_id);
    }

    public void requestRegistration(View view) {
//        Intent intent = new Intent(this, CardsActivity.class);
//        startActivity(intent);

//        Intent intent = new Intent(this, MainCardActivity.class);
//        startActivity(intent);


        // TODO: Send clientID and androidID to a Lambda API endpoint (Dan provides it)
        // TODO: Start a new activity intent for the status activity page
        JSONObject obj = new JSONObject();
        try {
            obj.put("instance_id", android_id.getText().toString());
            obj.put("client_id", client_id.getText().toString());

        }catch (JSONException e){
            System.out.println(e.getMessage());
        }

        String urlString = "https://lvtsme4ili.execute-api.us-east-1.amazonaws.com/master/devices/register"; // URL to call
        String data = obj.toString(); //data to post
        OutputStream out = null;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            conn.setRequestProperty("Accept","application/json");
            conn.setDoOutput(true);
            conn.setDoInput(true);

            JSONObject jsonParam = obj;

            Log.i("JSON", jsonParam.toString());
            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            //os.writeBytes(URLEncoder.encode(jsonParam.toString(), "UTF-8"));
            os.writeBytes(jsonParam.toString());

            os.flush();
            os.close();

            Log.i("STATUS", String.valueOf(conn.getResponseCode()));
            Log.i("MSG" , conn.getResponseMessage());

            conn.disconnect();
        } catch (Exception e) {
                e.printStackTrace();
        }
        Intent intent = new Intent(this, StatusActivity.class);
        String mClient_ID = client_id.getText().toString();
        String mAndroid_ID = android_id.getText().toString();
        intent.putExtra(CLIENT_ID, mClient_ID);
        intent.putExtra(ANDROID_ID, mAndroid_ID);
        startActivity(intent);
    }
}
