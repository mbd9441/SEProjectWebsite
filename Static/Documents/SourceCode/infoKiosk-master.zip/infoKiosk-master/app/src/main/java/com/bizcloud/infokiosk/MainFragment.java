package com.bizcloud.infokiosk;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.leanback.app.BrowseSupportFragment;

public class MainFragment extends BrowseSupportFragment {
    private static final String TAG = MainFragment.class.getSimpleName();

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.i(TAG, "onActivityCreated");
        super.onActivityCreated(savedInstanceState);

        Intent intent = new Intent(getActivity(), VerticalGridActivity.class);
        startActivity(intent);
    }


}