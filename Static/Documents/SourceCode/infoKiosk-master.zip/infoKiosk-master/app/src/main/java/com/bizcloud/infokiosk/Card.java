package com.bizcloud.infokiosk;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import com.google.gson.annotations.SerializedName;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;


public class Card {
    private String title;
    private String message;
    private String link;
    private Bitmap qr;
    @SerializedName("extraText") private String mExtraText = "";
    @SerializedName("localImageResource") private String mLocalImageResource = null;

    public Card( String title, String message, String link) {
        this.title = title;
        this.message = message;
        this.link = link;
        generateQR();
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public String getLink() {
        return link;
    }

    public String getExtraText() {
        return mExtraText;
    }


    public int getLocalImageResourceId(Context context) {
        return context.getResources().getIdentifier(getLocalImageResourceName(), "drawable",
                context.getPackageName());
    }

    public String getLocalImageResourceName() {
        return mLocalImageResource;
    }

    public Drawable getQR(){
        Drawable d = new BitmapDrawable(qr);
        return d;
    }
    private void generateQR() {
        // https://gist.github.com/adrianoluis/fa9374d7f2f8ca1115b00cc83cd7aacd
        BitMatrix result;

        try {
            result = new MultiFormatWriter().encode(link, BarcodeFormat.QR_CODE, 50, 50, null);
        } catch (IllegalArgumentException | WriterException e) {
            // Unsupported format
            return;
        }

        final int w = result.getWidth();
        final int h = result.getHeight();
        final int[] pixels = new int[w * h];

        for (int y = 0; y < h; y++) {
            final int offset = y * w;
            for (int x = 0; x < w; x++) {
                pixels[offset + x] = result.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }

        final Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, 50, 0, 0, w, h);

        qr = bitmap;
    }

    @Override
    public String toString(){
        String to = title + " " + message + " " + link;
        return to;
    }
}