package com.bizcloud.infokiosk;

import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

public class MainCardActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_main);
    }
}
