package com.bizcloud.infokiosk.presenter;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;

import com.bizcloud.infokiosk.Card;
import com.bizcloud.infokiosk.CustomImageCardView;
import com.bizcloud.infokiosk.R;

import androidx.core.content.ContextCompat;
import androidx.leanback.widget.ImageCardView;
import androidx.leanback.widget.Presenter;
/*
 * A CardPresenter is used to generate Views and bind Objects to them on demand.
 * It contains an Image CardView
 */
public class CardPresenter extends Presenter {
    private int mSelectedBackgroundColor = -1;
    private int mDefaultBackgroundColor = -1;
    private Drawable mDefaultCardImage;

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent) {
//        ImageCardView cardView = new ImageCardView(parent.getContext()) {
//        };

        CustomImageCardView cardView = new CustomImageCardView(parent.getContext()) {
        };

        Resources res = parent.getResources();
        int width = res.getDimensionPixelSize(R.dimen.grid_item_width);
        int height = res.getDimensionPixelSize(R.dimen.grid_item_height);

        cardView.setLayoutParams(new ViewGroup.LayoutParams(width, height));
        cardView.setFocusable(false);
        cardView.setFocusableInTouchMode(false);
        cardView.setBackgroundColor(ContextCompat.getColor(parent.getContext(),
                R.color.custom_background_info_kiosk));
        //cardView.setTitleColor(R.color.custom_text_color);
        return new ViewHolder(cardView);
    }

    @Override
    public void onBindViewHolder(Presenter.ViewHolder viewHolder, Object item) {

        //ImageCardView cardView = (ImageCardView) viewHolder.view;
        CustomImageCardView cardView = (CustomImageCardView) viewHolder.view;
        Card card = (Card) item;

        cardView.setTitleText(card.getTitle());
        cardView.setTitleColor(R.color.custom_text_color);
        cardView.setContentColor(R.color.custom_content_color);
        cardView.setContentText(card.getMessage());
        Resources res = cardView.getResources();
        int width = res.getDimensionPixelSize(R.dimen.card_width) ;
        int height = res.getDimensionPixelSize(R.dimen.card_height) ;
        cardView.setMainImageDimensions(width, height);
        cardView.setMainImage(card.getQR());

    }

    @Override
    public void onUnbindViewHolder(Presenter.ViewHolder viewHolder) {
        ImageCardView cardView = (ImageCardView) viewHolder.view;

        cardView.setBadgeImage(null);
        cardView.setMainImage(null);
    }
}