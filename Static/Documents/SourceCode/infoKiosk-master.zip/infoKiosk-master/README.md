# infoKiosk
Senior Student Project to create an interactive information kiosk display unit

Please see /Docs for additional project info

Confidentiality Notice: This project contains confidential, proprietary information of UberTejas LLC. It is intended solely for the named recipient(s) listed above and should be maintained in strictest confidence. If you are not the intended recipient, you are hereby notified that any disclosure, copying, distribution, or use of the information contained herein (including any reliance thereon) is STRICTLY PROHIBITED. If you have received this e-mail in error, please immediately notify the sender and delete this information from your computer and destroy any related paper copies.