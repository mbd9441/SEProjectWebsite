Read Me

Dependencies:
	Install Android Studio (above 3)
	JDK
	API 28: Android 9 (Pie)
	Change gradle to 4.6 and not 3.3

Get Started by:

1. Cloning the repository

Start up Instructions:

1. Open Android Studio
2. Open existing project, select the info kiosk directory
3. Once the cradle builds the project, confirm that the project toolbar displays the app directory
4. Click the run 'app' button and create a virtual device
5. The device should be a tv (1080p) and select next
6. Download Pie and finish the set up
7. Click the Android TV and click ok
8. Go to the CardsActivity and add in the credentials required (Should already be there)
8. Add the credentials for cognito in the awsconfig file found under res/raw (Should already be there)
9. Run the app
10. When the app runs, an emulator of a tv should start up
11. The first screen seen should be the register tv page, if not click the back (triangle) button on the emulator toolbar
11. Click the button to register
12. Should automatically connect
13. Click the topic input field and write in the fixed topic "testPub" to subscribe to it (to exit keyboard click the back button on the emulator toolbar)
14. Press the subscribe button

TV should now be waiting for any incoming published messages from the web app
When web app pushes a content, the first card should be populated with the information

** Trouble Shooting

If you encounter the error:
`javax.net.ssl.SSLHandshakeException: Chain validation failed` or similar

This is due to the time on your emulator being incorrect. To fix, change the emulator date and time to match your system's and restart the app.
