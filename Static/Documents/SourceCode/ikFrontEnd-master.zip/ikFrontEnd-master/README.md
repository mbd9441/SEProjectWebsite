# ikFrontEnd
All Front End related to InfoKiosk Project

**Setup instructions**

    1. Install angular CLI v6
        a. Install Node.
            i. https://nodejs.org/en/download/
        b. npm install -g @angular/cli@6
        c. cd e-bulletin/
        d. npm install --save
    2. get newest version of python.
         a. https://www.python.org/downloads/
         b. $ python --version
         c. $ pip --version
    3. Install AWS Command Line Interface
        a. pip install awscli
    4. Configure AWS CLI
        a. restart CMD
        b. aws configure, enter credentials

**Run the app in development**

    1. ng serve
        a. Run and open: ng serve --open

**Build the application**
    
    1. ng build
        a. Output can be found in dist/
 
**Test the application**

    1. ng test.

**Deploying the application to the cloud via AWS Code Pipeline**

    1. Log in to AWS console
    2. Go to Developer tools / Code Pipeline
    3. Select InfoKioskS3Master
    4. Select Release Change

**Deploying the application to the cloud via AWS CLI (alternate)**

    1. $ cd ikFrontEnd
    2. $ git pull master
    3. $ cd e-bulletin
    4. $ ng build
    5. $ cd dist 
    6. $ cd e-bulletin2
    7. $ aws s3 cp . s3://serverlessapp-bkt-2018/ --recursive --acl public-read
