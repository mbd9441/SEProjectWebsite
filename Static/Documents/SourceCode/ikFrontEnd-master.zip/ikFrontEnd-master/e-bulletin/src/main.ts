import { config } from './app/config/config';
import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import * as AWS from 'aws-sdk';
const AmazonCognitoIdentity = require('amazon-cognito-auth-js');

const authenticateCognito = ( ) => {
    AWS.config.region = config.cognito.region;
    const authData = {
        IdentityPoolId: config.cognito.indentityPoolId,
    };
    // TODO: replace with BizCloud Identity Pool Id
    AWS.config.credentials = new AWS.CognitoIdentityCredentials({IdentityPoolId: authData.IdentityPoolId});
    // @ts-ignore
    AWS.config.credentials.get((err) => {
        if (err){
            console.log(err);
        }
        else {
            // @ts-ignore
            const principal = AWS.config.credentials.identityId;
            const iot = new AWS.Iot()
            // TODO: replace with BizCloud's IoT Policy Name
            iot.attachPolicy({policyName: config.iot.policyName, target: principal}
            , (err) => {
              if (err) {
                console.log(err);
              }
            });

        }
    });
}
if (environment.production) {
  enableProdMode();
}
authenticateCognito();
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));

