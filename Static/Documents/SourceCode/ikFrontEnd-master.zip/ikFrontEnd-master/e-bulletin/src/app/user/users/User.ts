import UsernameAttribute from "../attributes/UsernameAttribute";
import EmailAttribute from "../attributes/EmailAttribute";

export default interface User {

    userName: UsernameAttribute;
    email: EmailAttribute;
    isConfirmed: boolean;
    clientID?: number;
    clientName?: string;
    sectionID?: number
    sectionName?: string;
    owner?: boolean;

    setClientID?(clientID: number);
    setSectionID?( sectionID: number );
}


export enum UserTypes {
    CLI_ACC_OWNER = 'Client-Account-Owner',
    CLI_ACC_ADMIN = 'Client-Account-Administrator',
    SEC_ADMIN = 'Section-Administrator',
    SYS_ADMIN = 'System-Administrator'
}
