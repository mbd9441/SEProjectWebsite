import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { DeviceService } from "./device.service";
import { Observable, BehaviorSubject } from "rxjs";
import { Device } from "./Device";
import { catchError } from 'rxjs/operators';
import { of } from "zen-observable";
import {AuthService} from "../auth/auth.service";

export class DeviceDataSource implements DataSource<Device> {

    private deviceSubject = new BehaviorSubject<Device[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);
    private clientID: number;
    private sectionID: number;
    private userRole: string;

    public loading = this.isLoading.asObservable();
    public deviceData = this.deviceSubject.asObservable();
    constructor( private deviceService: DeviceService, private authService: AuthService ){ }

    public connect( collectionViewer: CollectionViewer ): Observable<Device[]> {
        return this.deviceSubject.asObservable();
    }

    public disconnect( collectionViewer: CollectionViewer ): void {
        this.deviceSubject.complete();
        this.isLoading.complete();
    }

    public loadDevices (): void {
        this.isLoading.next(true);
        setTimeout( () =>
            this.loadDevicesByRole()
            ,3000
        )
    }


    private loadDevicesAdmin(): void {
        this.deviceService.getDevices().subscribe(
          ( result: any ) => {
            if ( result.ok ){
              this.deviceSubject.next( result.body.message );
              this.isLoading.next( false );
            }
          },
          ( error: any  ) => {
            if( error ){
              console.log( error );
            }
          }
        )
    }

    private loadDevicesByClient(): void {
        this.deviceService.getDevicesByClient(this.clientID).subscribe(
          ( result: any ) => {
            if ( result.ok ){
              this.deviceSubject.next( result.body.message );
              this.isLoading.next( false );
            }
          },
          ( error: any  ) => {
            if( error ){
              console.log( error );
            }
          }
        )
    }

    private loadDevicesBySection(): void {
        this.deviceService.getDevicesBySection(this.sectionID).subscribe(
          ( result: any ) => {
            if ( result.ok ){
              this.deviceSubject.next( result.body.message );
              this.isLoading.next( false );
            }
          },
          ( error: any  ) => {
            if( error ){
              console.log( error );
            }
          }
        )
    }

    async loadDevicesByRole(){
        await this.getAttributes();
        if (this.sectionID){
          this.loadDevicesBySection();
          console.log("section")
        } else {
          if (this.clientID){
            this.loadDevicesByClient();
            console.log("client")
          } else {
            this.loadDevicesAdmin();
            console.log("admin")
          }
        }
    }
  
    private loadDeviceRequests(): void {
      this.deviceService.getPendingDevices().subscribe(
        ( result: any ) => {
          if ( result.ok ){
            this.deviceSubject.next( result.body.message );
            this.isLoading.next( false );
          }
        },
        ( error: any  ) => {
          if( error ){
            console.log( error );
          }
        }
      )
  }

  private loadDeviceRequestsByClient(id: number): void {
    this.deviceService.getPendingDevicesByClient(id).subscribe(
      ( result: any ) => {
        if ( result.ok ){
          this.deviceSubject.next( result.body.message );
          this.isLoading.next( false );
        }
      },
      ( error: any  ) => {
        if( error ){
          console.log( error );
        }
      }
    )
}

    async getAttributes(){
        const attributes = await this.authService.getAttributes();
        this.userRole = attributes["custom:role"];
        this.clientID = attributes["custom:client_id"];
        this.sectionID = attributes["custom:section_id"];
    }

}
