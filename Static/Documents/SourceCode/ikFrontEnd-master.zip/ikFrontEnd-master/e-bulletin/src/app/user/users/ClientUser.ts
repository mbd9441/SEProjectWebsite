import User from "./User";
import EmailAttribute from "../attributes/EmailAttribute";
import UsernameAttribute from "../attributes/UsernameAttribute";
import {UserService} from "../user.service";
import {ClientService} from "../../client/client.service";
import {Client} from "../../client/Client";

export default class ClientUser implements User {
    email: EmailAttribute;
    userName: UsernameAttribute;
    isConfirmed: boolean = false;
    clientID: number;
    sectionID = null;
    owner: boolean = false;
    clientName: string;
    constructor(private clientService: ClientService){}

    setClientID( clientID ): void {
        this.clientID = clientID;
        this.loadClient();
    }

    private loadClient(): void {
      // console.log( "client "+this.clientID );
      this.clientService.getClientById(this.clientID).subscribe(
        ( response: any ) => {
          this.clientName = response.body.message.client_name? response.body.message.client_name: "";
        }
      );
    }

}
