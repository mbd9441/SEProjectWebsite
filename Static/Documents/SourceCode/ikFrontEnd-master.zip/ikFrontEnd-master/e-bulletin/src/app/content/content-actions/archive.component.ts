import {Component, OnInit} from "@angular/core";

@Component({
  selector: 'archive-content',
  templateUrl: './archive.component.html',
  styleUrls: ['../content.component.css']
})

export class ArchiveComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
