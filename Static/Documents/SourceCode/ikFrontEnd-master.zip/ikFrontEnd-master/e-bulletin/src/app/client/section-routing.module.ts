import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {ClientComponent} from "./client/client.component";
import {SectionComponent} from "./section/section.component";
import {SectionListComponent} from "./section-list/section-list.component";
import {NewSectionFormComponent} from "./new-section/new-section.component";
import {AuthGuard} from "../auth/auth.guard";
import { SectionDetailComponent } from './section-detail/section-detail.component';



const sectionRoutes: Routes = [
  {
    path: 'sections',
    component: SectionComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: '',
        component: SectionListComponent,
      },
      {
        path: 'new',
        component: NewSectionFormComponent
      },
      {
        path: ':id',
        component: SectionComponent,
        children: [
          {
            path: '',
            component: SectionDetailComponent
          },
          {
            path: 'details',
            component: SectionDetailComponent
          }
        ]
      }
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      sectionRoutes,
      {
        enableTracing: true
      }
    )
  ],
  exports: [
    RouterModule
  ]
})

export class SectionRoutingModule { }

