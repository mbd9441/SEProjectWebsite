import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import {UserTypes} from "../user/users/User";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  title: string = 'Welcome to the E-bulletin!';
  constructor(private router: Router, private auth: AuthService) { }

  ngOnInit() {
  }

  async navigate(event){
      event.preventDefault();
      await this.auth.isAuthenticated()
      .then(
          async (authenticated) => {

            if( !authenticated ){
              this.router.navigate(['login']);
            }
            else {
              if ( await this.auth.getUserRole() === UserTypes.SYS_ADMIN ){
                this.router.navigate(['client']);
              } else {
                this.router.navigate(['content']);
              }

            }
          }
      )
      .catch(
        ( error ) => {
            console.error( error );
        }
      )
      ;

  }

}
