import { NgModule } from "@angular/core";
import { ClientComponent } from "./client/client.component";
import { ClientListComponent } from "./client-list/client-list.component";
import { ClientDetailComponent } from "./client-detail/client-detail.component";
import { NewClientFormComponent } from "./new-client/new-client.component";
import { ClientRoutingModule } from "./client-routing.module";
import { CommonModule } from "@angular/common";
import {FormsModule} from "@angular/forms";
import { SectionRoutingModule } from "./section-routing.module";
import { NavbarModule } from '../navbar/navbar.module';
import {LogoutModule} from "../logout/logout.module";
import { FlexLayoutModule } from '@angular/flex-layout';

import {
    MatTableModule,
    MatProgressSpinnerModule,
    MatCheckboxModule,
    MatIconModule,
    MatMenuModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSidenavModule,
    MatListModule,
    MatSelectModule,
    } from '@angular/material';
import { SectionListComponent } from "./section-list/section-list.component";
import { SectionComponent } from "./section/section.component";
import { SectionDetailComponent } from "./section-detail/section-detail.component";
import { NewSectionFormComponent } from "./new-section/new-section.component";

@NgModule({
    declarations: [
        ClientComponent,
        ClientListComponent,
        ClientDetailComponent,
        NewClientFormComponent,
        SectionListComponent,
        SectionComponent,
        SectionDetailComponent,
        NewSectionFormComponent,
    ],
    imports: [
        ClientRoutingModule,
        SectionRoutingModule,
        CommonModule,
        FormsModule,
        MatTableModule,
        MatProgressSpinnerModule,
        MatCheckboxModule,
        MatIconModule,
        MatMenuModule,
        MatButtonModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        MatSidenavModule,
        MatListModule,
        MatSelectModule,
        NavbarModule,
        LogoutModule,
        FlexLayoutModule
    ]
})

export class ClientModule {}
