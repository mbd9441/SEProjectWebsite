import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {ContentComponent} from "./content.component";
import {ContentListComponent} from "./content-list/content-list.component";
import {NewContentFormComponent} from "./new-content/new-content.component";
import { ContentRequestFormComponent } from "./content-request/content-request-form.component";
import { ContentRequestListComponent } from "./content-request/content-request-list.component";
import {PushFormComponent} from "./content-actions/push-form.component";
import {AuthGuard} from "../auth/auth.guard";
import { ContentRequestSuccessComponent } from './content-request/content-request-success.component';
import { ContentDetailComponent } from './content-detail/content-detail.component';
import { ContentRequestComponent } from './content-request/content-request.component';


const contentRoutes: Routes = [
  {
    path: 'content',
    component: ContentComponent,
    // canActivate: [AuthGuard],
    children: [
      {
        path: '',
        component: ContentListComponent,
        canActivate: [AuthGuard],
      },
      {
          path: 'new',
          component: NewContentFormComponent,
          canActivate: [AuthGuard],
      },
      {
          path: 'push',
          component: PushFormComponent,
          canActivate: [AuthGuard],
      },
      {
          path: 'request/:clientID/:sectionID/:deviceID',
          component: ContentRequestFormComponent
      },
      {
        path: 'success',
        component: ContentRequestSuccessComponent
      },
      {
          path: ':id/detail',
          component: ContentDetailComponent
      },
      {
        path: 'requests',
        component: ContentRequestComponent,
        children: [
            {
                path: '',
                component: ContentRequestListComponent
            },
          ]
      },
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      contentRoutes,
      {
        enableTracing: true
      }
    )
  ],
  exports: [
    RouterModule
  ]
})

export class ContentRoutingModule { }

