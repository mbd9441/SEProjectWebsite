import {Component, EventEmitter, Input, OnInit, Output, DoCheck} from '@angular/core';
import {AuthService} from "../auth/auth.service";
import {Router} from "@angular/router";

@Component({
  selector: 'confirm-signup',
  templateUrl: './confirm-signup.component.html',
  styleUrls: ['./register.component.css']
})

export class ConfirmSignupComponent implements OnInit {
  confirmationCode: string = "";
  username: string = "";
  valid: boolean = true;
  resent: boolean = null;

  constructor(private authService: AuthService, private router: Router) { }

  async onSubmit( e ) {

      e.preventDefault();
      await this.authService.confirmUser(this.username, this.confirmationCode)
      .then(
          (result) => {
              this.router.navigate(['login']);
              this.valid = true;
          }
      )
      .catch(
          ( error ) => {

              console.error(error);
              this.valid = false;
          }
      )
  }

  onCancel( e ){
      e.preventDefault();
      this.router.navigate(['dashboard']);
  }

  routeToResend( e ) {
    e.preventDefault();
    this.router.navigate(['resend']);

  }
  ngOnInit() {}


}
