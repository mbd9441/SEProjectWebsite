import { Component, OnInit, Input } from '@angular/core';
import { Content } from '../Content';

@Component({
  selector: 'content-request-detail',
  templateUrl: './content-request-detail.component.html',
  styleUrls: ['./content-request.component.css']
})
export class ContentRequestDetailComponent implements OnInit {
  @Input() 
  content: Content;

  constructor() { }

  ngOnInit() {
  }

}
