import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import { MatToolbarModule, MatIconModule, MatButtonModule, MatSidenavModule, MatListModule, MatMenuModule } from "@angular/material";
import { NavbarComponent } from "./navbar.component";
import { LogoutModule } from "../logout/logout.module";
import { FlexLayoutModule } from "@angular/flex-layout";
import { SidenavComponent } from "./sidenav.component";

@NgModule({
    imports: [
        CommonModule,
        MatToolbarModule,
        MatIconModule,
        MatButtonModule,
        LogoutModule,
        FlexLayoutModule,
        MatSidenavModule,
        MatListModule,
        MatMenuModule
    ],
    declarations: [NavbarComponent, SidenavComponent],
    exports: [NavbarComponent, SidenavComponent ]
})

export class NavbarModule {}
