import {Component, OnInit} from "@angular/core";
import * as AWS from 'aws-sdk';

@Component({
  selector: 'push-content-form',
  templateUrl: './push-form.component.html',
  styleUrls: ['../content.component.css']
})

export class PushFormComponent implements OnInit {
    
    iotdata: AWS.IotData;
    constructor(){
        // this.authenticateCognito = this.authenticateCognito.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        // this.authenticateCognito();
        // this.iotdata = new AWS.IotData({endpoint: 'akfhq5zfyp890-ats.iot.us-east-2.amazonaws.com'});
    }

    ngOnInit(){}

   
    onSubmit( ev ): void {
        ev.preventDefault();
        
        const params = {
            topic: 'testPub',
            payload: 'testing testing 123',
            qos: 0
        }
        // TODO: fill in with BizCloud endpoint
        const iotdata = new AWS.IotData({endpoint:''});
        iotdata.publish(params, (err, result) => {
            if ( err ) {
                console.log( err, err.stack );
            }
            else {
              console.log( result );
            }
        })
  }
}




