import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpResponse} from "@angular/common/http";
import { Device } from './Device';
import { config } from '../config/config';
import { Observable, BehaviorSubject } from 'rxjs';
import { DeviceRequest } from './DeviceRequest';
import { DeviceApproval } from './DeviceApproval';
import {DeviceContent} from "../content/device-content";

@Injectable({
    providedIn: 'root'
})
export class DeviceService {

    private startApprovalSource = new BehaviorSubject<DeviceRequest>(null);

    approvalStarted = this.startApprovalSource.asObservable();

    constructor(private http: HttpClient){}

    getDevices(): Observable<HttpResponse<Device[]>> {
        return this.http.get<Device[]>(config.api.invokeUrl+'devices', { observe: 'response' } );
    }

    getDevicesByClient(client_id: number): Observable<HttpResponse<Device[]>> {
        return this.http.get<Device[]>(config.api.invokeUrl+'devices/client/'+client_id, { observe: 'response' } );
    }

    getDevicesBySection(section_id: number): Observable<HttpResponse<Device[]>> {
        return this.http.get<Device[]>(config.api.invokeUrl+'devices/section/'+section_id, { observe: 'response' } );
    }

    getDevice(deviceID : number ): Observable<HttpResponse<Device>> {
        return this.http.get<Device>(config.api.invokeUrl+'devices/'+deviceID, { observe: 'response' } );
    }

    editDevice( updatedDevice: Device ): Observable<HttpResponse<Device>> {
        return this.http.post<Device>(config.api.invokeUrl+'devices/update', updatedDevice, {observe: 'response'});
    }

    getPendingDevices():  Observable<HttpResponse<Device[]>> {
        return this.http.get<Device[]>(config.api.invokeUrl+'devices/pending', { observe: 'response' } );
    }

    getPendingDevicesByClient( clientID: number ):  Observable<HttpResponse<Device[]>> {
      return this.http.get<Device[]>(config.api.invokeUrl+'devices/pending/client/'+clientID, { observe: 'response' } );
    }

    approveDevice( deviceID: number, approvalData: DeviceApproval ): Observable<HttpResponse<Device>> {
        return this.http.post<Device>(config.api.invokeUrl+'devices/approve/'+deviceID, approvalData, {observe: 'response'});
    }

    denyDevice( deviceID: number, instanceID: string ): Observable<HttpResponse<Device>> {
        const postData = {instance_id: instanceID}
        return this.http.post<Device>(config.api.invokeUrl+'devices/deny/'+deviceID, postData, {observe: 'response'});
    }

    startApproval( deviceRequest: DeviceRequest ){
        this.startApprovalSource.next( deviceRequest );
    }


}
