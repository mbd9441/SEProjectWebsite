import { Component, OnInit } from '@angular/core';
import { DeviceService } from '../device.service';
import { DeviceRequest } from '../DeviceRequest';
import { SectionService } from 'src/app/client/section.service';
import { BehaviorSubject } from 'rxjs';
import {AuthService} from "../../auth/auth.service";
import { DeviceRequestDataSource } from '../device-request.data-source';
import { SelectionModel } from "@angular/cdk/collections";
import { MatDialog } from '@angular/material';
import { ApprovalFormComponent } from './approval-form.component';

@Component({
  selector: 'device-requests',
  templateUrl: './device-request-list.component.html',
  styleUrls: ['../devices.component.css']
})

export class DeviceRequestListComponent implements OnInit {
    requests: DeviceRequest[];
    dataSource: DeviceRequestDataSource;
    tableColumns: string[] = [];
    requestsSource = new BehaviorSubject<DeviceRequest[]>([]);
    selection = new SelectionModel<DeviceRequest>(true, []);

    constructor(public modal: MatDialog, private deviceService: DeviceService, private authService:AuthService, private sectionService: SectionService){
      this.tableColumns = ["select","name", "id", "section", "detail"];
      this.dataSource = new DeviceRequestDataSource( this.deviceService, this.authService, this.sectionService );
      this.dataSource.requestData.subscribe( (requests: DeviceRequest[]) => this.requests = requests  );
  }

    ngOnInit() {
        this.loadRequests();
    }

    private async loadRequests() {
        await this.dataSource.loadDevicesByRole();
        
    }

    onDeny(id: number){
        this.requests = this.requests.filter(  (request: DeviceRequest) => request.device.device_id !== id );
        this.requestsSource.next(this.requests);
    }
  
    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected(): boolean {
        const numSelected = this.selection.selected.length;
        const numRows = this.requests.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle(): void {
        this.isAllSelected() ?
            this.selection.clear() :
            this.requests.forEach(row => this.selection.select(row));
    }

    onReload( silent:boolean = false ): void {
        this.dataSource.loadDevicesByRole();
    }

    approveDeviceModal(request: DeviceRequest): void {
      this.modal.open(ApprovalFormComponent, {
          width: '50%',
          data: { reload: (  ) => this.onReload(), request }
      });
    }

}
