import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {LogoutButton} from "./logout.button";
import { MatButtonModule } from "@angular/material";

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule
    ],
    declarations: [
        LogoutButton
    ],
    exports: [LogoutButton]
})

export class LogoutModule {}
