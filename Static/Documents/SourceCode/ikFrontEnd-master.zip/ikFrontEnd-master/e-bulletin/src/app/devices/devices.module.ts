import { NgModule } from "@angular/core";
import { DevicesComponent } from "./devices.component";
import { DeviceListComponent } from "./device-list/device-list.component";
import { NewDeviceFormComponent } from "./new-device/new-device-form.component";
import { DeviceDetailComponent } from "./device-detail/device-detail.component";
import { DevicesRoutingModule } from "./devices-routing.component";
import { CommonModule } from "@angular/common";
import { DeviceRequestComponent } from "./device-request/device-request.component";
import { DeviceRequestDetailComponent } from "./device-request/device-request-detail.component";
import { ApprovalFormComponent } from "./device-request/approval-form.component";
import { FormsModule } from "@angular/forms";
import { DeviceRequestListComponent } from "./device-request/device-request-list.component";
import { DeviceContentListComponent } from './device-content-list/device-content-list.component';
import { 
    MatTableModule, 
    MatProgressSpinnerModule, 
    MatCheckboxModule, 
    MatIconModule, 
    MatMenuModule, 
    MatButtonModule, 
    MatDialogModule, 
    MatFormFieldModule,
    MatInputModule,
    MatSidenavModule,
    MatListModule,
    MatSelectModule,
    MatSelect,
    MatSlideToggleModule,
    MatCardModule
    } from '@angular/material';
import { SharedModule } from "../shared/shared.module";
import { DeviceContentDetailComponent } from './device-content-detail/device-content-detail.component';
import { NavbarModule } from "../navbar/navbar.module";
import { FlexLayoutModule } from "@angular/flex-layout";

@NgModule({
    declarations: [
        DevicesComponent,
        DeviceDetailComponent,
        NewDeviceFormComponent,
        DeviceListComponent,
        DeviceRequestComponent,
        DeviceRequestListComponent,
        DeviceRequestDetailComponent,
        ApprovalFormComponent,
        DeviceContentListComponent,
        DeviceContentDetailComponent,
    ],
    imports: [
        CommonModule,
        DevicesRoutingModule,
        FormsModule,
        MatProgressSpinnerModule,
        MatCardModule,
        SharedModule,
        MatTableModule,
        MatCheckboxModule,
        MatMenuModule,
        MatIconModule,
        MatButtonModule,
        NavbarModule,
        MatSlideToggleModule,
        FlexLayoutModule,
        MatSelectModule,
        MatButtonModule,
        MatDialogModule,
        MatFormFieldModule,
        MatInputModule,
        MatSidenavModule,
        MatListModule
    ],
    exports: [
        DeviceRequestDetailComponent,
    ]
})
export class DevicesModule { }
