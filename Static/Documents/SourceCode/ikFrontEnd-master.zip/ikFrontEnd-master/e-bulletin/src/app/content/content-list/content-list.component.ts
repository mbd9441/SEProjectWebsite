import {Component, OnInit} from "@angular/core";
import { ContentService } from "../content.service";
import { Content } from "../Content";
import { CollectionViewer, DataSource, SelectionModel } from "@angular/cdk/collections";
import { ContentDataSource } from "../content.data-source";
import { MatDialog } from "@angular/material";
import { NewContentFormComponent } from "../new-content/new-content.component";
import { AuthService } from "src/app/auth/auth.service";

@Component({
  selector: 'content-list',
  templateUrl: './content-list.component.html',
  styleUrls: ['../content.component.css']
})

export class ContentListComponent implements OnInit{
    dataSource: ContentDataSource;
    tableColumns: string[] = [];
    selection = new SelectionModel<Content>(true, []);
    content: Content[] = []
    userRole: string = '';
    clientID: number;
    sectionID: number;

    constructor(public modal: MatDialog, private contentService: ContentService, private authService:AuthService){
        this.tableColumns = ["select","title", "client", "section", "status", "submitter", "push"];
        this.dataSource = new ContentDataSource( this.contentService );
        this.dataSource.contentData.subscribe( (content: Content[]) => this.content = content  );
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected(): boolean {
        const numSelected = this.selection.selected.length;
        const numRows = this.content.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle(): void {
        this.isAllSelected() ?
            this.selection.clear() :
            this.content.forEach(row => this.selection.select(row));
    }

    ngOnInit(){
        this.loadContent();
    }

    openModal(): void {
        this.modal.open(NewContentFormComponent, {
            width: '50%',
            data: { reload: (  ) => this.onReload() }
        });
    }

    onReload( silent:boolean = false ): void {
        this.loadContent();
    }

    async loadContent(){
        await this.getAttributes();
        if (this.sectionID){
            this.dataSource.loadContentsBySection(this.sectionID);
            console.log("section" + this.sectionID)
        } else {
            if (this.clientID){
                this.dataSource.loadContentsByClient(this.clientID);
                console.log("client" + this.clientID)
            } else {
                this.dataSource.loadContents();
            }
        }
    }


    async getAttributes(){
        const attributes = await this.authService.getAttributes();
        this.clientID = attributes["custom:client_id"];
        this.sectionID = attributes["custom:section_id"];
        this.userRole = attributes["custom:role"];
        console.log("Client :" + this.clientID + " Section: " + this.sectionID)
    }

}
