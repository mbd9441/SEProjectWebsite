import CognitoAttribute from "../attributes/CognitoAttributeType";

export interface CognitoUserObj {
  Username: string,
  Attributes: CognitoAttribute[],
  UserCreateDate: Date,
  UserLastModifiedDate: Date,
  Enabled: boolean,
  UserStatus: string,
}
