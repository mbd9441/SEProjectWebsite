import {Component, OnInit} from "@angular/core";

@Component({
  selector: 'account-holder-registration',
  templateUrl: './account-holder-registration.component.html',
  styleUrls: ['../register.component.css']
})
export class AccountHolderRegistrationComponent implements OnInit {

  constructor(){}

  onSubmit(submitted: boolean): void {
    if (submitted)
      alert("The section account holder has been registered");

    else
      alert("Please try again");

  }

  ngOnInit(){

  }
}
