import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { Observable, BehaviorSubject } from "rxjs";
import { catchError } from 'rxjs/operators';
import { of } from "zen-observable";
import {SectionService} from "./section.service";
import {Section} from "./Section";

export class SectionDataSource implements DataSource<Section> {

    private Sectionsubject = new BehaviorSubject<Section[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);

    public loading = this.isLoading.asObservable();
    public SectionData = this.Sectionsubject.asObservable();
    constructor( private Sectionservice: SectionService ){ }

    public connect( collectionViewer: CollectionViewer ): Observable<Section[]> {
        return this.Sectionsubject.asObservable();
    }

    public disconnect( collectionViewer: CollectionViewer ): void {
        this.Sectionsubject.complete();
        this.isLoading.complete();
    }

    public loadSections (): void {

        this.isLoading.next(true),

        setTimeout( () =>
            this.Sectionservice.getSections()
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {

                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.Sectionsubject.next( result.body.message );

                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadSectionsByClient (id: number): void {

        this.isLoading.next(true),

        setTimeout( () =>
            this.Sectionservice.findByClientId(id)
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {

                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.Sectionsubject.next( result.body.message );

                        this.isLoading.next(false)
                        console.log(result.body.message)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

}
