import {Component, EventEmitter, Input, OnInit, Output, DoCheck} from '@angular/core';
import {AuthService} from "../auth/auth.service";
import {Router} from "@angular/router";

@Component({
  selector: 'resend-verification',
  templateUrl: './resend-verification.component.html',
  styleUrls: ['./register.component.css']
})

export class ResendVerificationComponent implements OnInit {
  username: string = "";
  resent: boolean = null;
  ERROR_MESSAGE: string = "That is not a valid username. Please try again.";
  constructor(private authService: AuthService, private router: Router) { }


  onCancel( e ){
    e.preventDefault();
    this.router.navigate(['confirm']);

  }

  async onResend( e ){
    await this.authService.resendConfirmationCode(this.username)
    .then(
      ( result ) => this.resent = true
    )
    .catch(
      ( error ) => {

          this.resent = false;
          console.error( error );
      }
    )
  }

  ngOnInit() {}


}
