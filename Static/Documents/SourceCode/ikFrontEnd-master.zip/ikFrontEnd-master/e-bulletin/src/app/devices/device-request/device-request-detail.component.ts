import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Device } from '../Device';
import { DeviceRequest } from '../DeviceRequest';
import { DeviceService } from '../device.service';
import { Router } from '@angular/router';

@Component({
  selector: 'device-request-detail',
  templateUrl: './device-request-detail.component.html',
  styleUrls: ['../devices.component.css']
})

export class DeviceRequestDetailComponent implements OnInit {

    valid: boolean = true;

    @Input() request: DeviceRequest;
    @Output() denied;
    constructor(private deviceService: DeviceService, private router: Router) { 
        this.denied = new EventEmitter();
    }

    ngOnInit() {
    }

    onDeny( event ){
        event.preventDefault();
        this.denyRequest();
    }

    onApprove( event ){
        event.preventDefault();
        console.log(this.request)
        // this.deviceService.startApproval( this.request );
        this.router.navigate(['/devices/requests/approve',this.request.device.device_id]);
    }

    

    private denyRequest(){
        const device: Device = this.request.device;
        this.deviceService.denyDevice( device.device_id, device.instance_id )
            .subscribe( response => {
                if (response.ok){
                    this.valid = true;
                    this.denied.emit(device.device_id);
                }
                else {
                    this.valid = false;
                }
            },
              error => {
                  this.valid = false;
              } 
        );
            
    }

    


}
