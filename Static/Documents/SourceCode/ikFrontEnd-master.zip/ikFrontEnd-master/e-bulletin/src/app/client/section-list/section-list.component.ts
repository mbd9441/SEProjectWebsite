import { Component, OnInit, Input } from '@angular/core';
import { SectionService } from '../section.service';
import { Section } from '../Section';
import { ActivatedRoute } from '@angular/router';
import { SectionDataSource } from '../section.data-source';
import { SelectionModel } from "@angular/cdk/collections";
import { AuthService } from 'src/app/auth/auth.service';
import { MatDialog } from '@angular/material';
import { NewSectionFormComponent } from '../new-section/new-section.component';
import { SectionDetailComponent } from '../section-detail/section-detail.component';



@Component({
  selector: 'section-list',
  templateUrl: './section-list.component.html',
  styleUrls: ['../client.css']
})

export class SectionListComponent implements OnInit {

  clientID: number = null;
  selection = new SelectionModel<Section>(true, []);
  dataSource: SectionDataSource;
  tableColumns: string[] = [];
  section: Section[];
  userRole: string;
  name: string;

  constructor(public modal: MatDialog, private sectionService: SectionService, private route: ActivatedRoute, private authService: AuthService ) { 
    this.tableColumns = ["select", "name", "id", "client", "details"];
    this.dataSource = new SectionDataSource( this.sectionService );
    this.dataSource.SectionData.subscribe( (section: Section[]) => this.section = section  );
  }

  ngOnInit() {
        this.route.queryParamMap.subscribe( params => { 
          this.clientID = parseInt(params.get("clientID"));
        });
        this.loadSections();
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.section.length;
    return numSelected === numRows;
}

/** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle(): void {
        this.isAllSelected() ?
            this.selection.clear() :
            this.section.forEach(row => this.selection.select(row));
    }

  async loadSections() {
    if ( !this.clientID  ){
      await this.getClientID();
    }
    if ( this.clientID != null ){
          console.log( this.clientID );
          this.dataSource.loadSectionsByClient( this.clientID );
      }
      else {
        this.dataSource.loadSections();
      }
  }

  async getClientID(){
    this.clientID = await this.authService.getUserClientId();
    return this.clientID;
  }

  onReload( silent:boolean = false ): void {
    this.loadSections();
  }

  openNewModal(id:number): void {
    console.log(id),
    this.modal.open(NewSectionFormComponent, {
        width: '50%',
        data: { reload: (  ) => this.onReload(), id }
    });
  }

  openDetailModal(section: Section): void {
    this.modal.open(SectionDetailComponent, {
        width: '50%',
        data: { reload: (  ) => this.onReload(), section }
    });
  }

}
