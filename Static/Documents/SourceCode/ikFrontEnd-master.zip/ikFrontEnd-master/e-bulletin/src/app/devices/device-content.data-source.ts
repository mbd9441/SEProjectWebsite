import {Content} from "../content/Content";
import {DeviceContent} from "../content/device-content";
import {DataSource} from "@angular/cdk/table";
import {BehaviorSubject, Observable} from "rxjs";
import {ContentService} from "../content/content.service";
import {CollectionViewer} from "@angular/cdk/collections";
import {catchError} from "rxjs/operators";
import {of} from "zen-observable";

export interface DeviceContentData {
    content: Content,
    deviceContent: DeviceContent
}

export class DeviceContentDataSource implements DataSource<DeviceContentData> {

    private deviceContentSubject = new BehaviorSubject<DeviceContentData[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);

    public loading = this.isLoading.asObservable();
    public deviceContentData = this.deviceContentSubject.asObservable();

    constructor(private contentService: ContentService) {
    }

    public connect(collectionViewer: CollectionViewer): Observable<DeviceContentData[]> {
      return this.deviceContentSubject.asObservable();
    }

    public disconnect(collectionViewer: CollectionViewer): void {
      this.deviceContentSubject.complete();
      this.isLoading.complete();
    }

    public loadDeviceContents (id:number, silentLoad: boolean = false): void {
      if (!silentLoad)
          this.isLoading.next(true);

      setTimeout( () =>
          this.contentService.getContentsByDevice(id)
          .pipe(
            catchError( error => {
              console.error(error);
              return of([]);
            })
          )
          .subscribe(
              ( result: any ) => {

                  const deviceContent = result.body.message
                  .map(
                      (  data ) => {

                          const { content_id, title, description, content,
                            status, submitter, client_id, section_id,
                            device_id, ...deviceContent } = data;

                          const newContent = new Content(content_id, title, description, content,
                            status, submitter, client_id, section_id, device_id);


                          const newDeviceContent = new DeviceContent(null,null,
                            deviceContent.time_published, deviceContent.is_active, deviceContent.is_saved);
                            newDeviceContent.content_id = deviceContent["Device_Content.content_id"];
                            newDeviceContent.device_id = deviceContent["Device_Content.device_id"];

                            return { content: newContent, deviceContent: newDeviceContent }

                      }
                  )
                  .sort(
                    ( a,b ) => a.time_published < b.time_published
                  );

                  this.deviceContentSubject.next( deviceContent );
                  if (!silentLoad)
                      this.isLoading.next(false);
            },
            ( error ) => {
              if ( error){
                console.error( error );
              }
            }
          )
        ,3000
      )
    }

    updateDeviceStatus( deviceContent: any ){
        this.contentService.updateDeviceContentStatus(deviceContent).subscribe(
            ( result: any ) => {
                if( !result.ok ) {
                    console.error( "An error occured" );
                }
            },
          (error: any ) => {
              console.error( error );
          }
        )
    }
}
