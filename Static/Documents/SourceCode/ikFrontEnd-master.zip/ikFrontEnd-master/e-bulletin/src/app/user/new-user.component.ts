import {Component, OnInit, Inject} from "@angular/core";
import {UserListComponent} from "./user-list.component";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import {Router} from "@angular/router";
import {AuthService} from "../auth/auth.service";
import {ClientService} from "../client/client.service";
import {UserDetailComponent} from "./user-detail.component";
import {UserTypes} from "./users/User";
import {Client} from "../client/Client";
import {Section} from "../client/Section";
import {SectionService} from "../client/section.service";
import {UserService} from "./user.service";


@Component({
  selector: 'new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./user.component.css']
})

export class NewUserFormComponent implements OnInit {
  // client: Client;
  userRole: string;
  clientID: number = null;
  sectionID: number = null;
  valid: boolean = true;
  firstName: string = "";
  lastName: string = "";
  email:string = "";
  selectedRole: string = null;
  types = UserTypes;
  roles: string[];
  clients: Client[] = [];
  sections: Section[] = [];
  selectedClient: Client;
  selectedSection: Section;
  constructor(private clientService: ClientService,
              private sectionService: SectionService,
              private authService: AuthService,
              private userService: UserService,
              public dialogRef: MatDialogRef<UserDetailComponent>){
    // this.client = new Client();
    // this.addClient = this.addClient.bind(this);
    this.selectedClient = new Client();
    this.selectedSection = new Section();
    this.getAttributes().then(
        result => {
          this.filterRoles();
          this.loadClients();
          this.loadSections();
        }
    );
    this.onSubmit = this.onSubmit.bind(this);
  }


  onSubmit(event){
    event.preventDefault();


    const inviteData = {
      "first_name":this.firstName,
      "last_name":this.lastName,
      "email": this.email,
      "role": this.selectedRole,
      "client_id": this.selectedClient.client_id,
      "section_id": this.selectedSection.section_id
    };

    this.userService.sendInvitation(inviteData).subscribe(
      (response: any) => {
          if( response.ok ){
              this.valid = true;
              this.dialogRef.close();
          }
          else {
              this.valid = false;
          }
      },
      (error: any) => {
          console.error(error);
          this.valid = false;
      }
    )
  }

  onCancel( event: any ){
    event.preventDefault();
    this.dialogRef.close();
  }

  onClientSelect(){
      console.log(this.selectedClient);
      this.getAllSectionsByClientId(this.selectedClient.client_id);
  }

  parseRole(role:string){
    return role.replace(/\-/g, ' ');
  }

  private async getAttributes(){
      const attributes = await this.authService.getAttributes();
      this.userRole = attributes["custom:role"];
      this.clientID = attributes["custom:client_id"];
      // this.userRole = "Client-Account-Administrator";
      // this.clientID = 12345678;
      this.sectionID = attributes["custom:section_id"];
      // this.sectionID = 6;

  }

  filterRoles(){
      switch( this.userRole ){
        case UserTypes.CLI_ACC_OWNER:
            this.roles = Object.values(this.types).filter(
                type => type != UserTypes.SYS_ADMIN
            );
            break;
        case this.types.CLI_ACC_ADMIN:
            this.roles = Object.values(this.types).filter(
              type => ( type != UserTypes.SYS_ADMIN
                                  && type != UserTypes.CLI_ACC_OWNER
              )

            );
            break;
        case UserTypes.SYS_ADMIN:
            this.roles = Object.values( this.types );
            break;
        default:
            this.roles = [];
            this.selectedRole = UserTypes.SEC_ADMIN;
            break;
      }
  }


  private loadClients(){
      switch(this.userRole){
        case UserTypes.SYS_ADMIN:
            this.getAllClients();
            break;
        default:
            this.getClientById();
            break;
      }
  }

  private loadSections(){
    switch(this.userRole){
      case UserTypes.SEC_ADMIN:
        this.getSectionBySectionId();
        break;
      default:
        this.getAllSectionsByClientId(this.clientID);
        break;
    }
  }

  private getAllClients(){
      this.clientService.getClients().subscribe(
          (response: any) => {
            this.clients = response.body.message;
          },
          (error: any) => {
            console.error( error );
          }

      )

  }

  private getClientById(){
      this.clientService.getClientById(this.clientID).subscribe(
        (response: any) => {
          this.selectedClient = response.body.message;
        },
        (error: any) => {
          console.error( error );
        }
      )
  }

  private getAllSections(){
      this.sectionService.getSections().subscribe(
          (response: any) => {
            this.sections = response.body.message;
          },
          (error: any) => {
            console.error( error );
          }
      )
  }

  private getAllSectionsByClientId(clientID: number){
      this.sectionService.findByClientId(clientID).subscribe(
          (response: any) => {
            this.sections = response.body.message;
          },
          (error: any) => {
            console.error( error );
          }
      )
  }

  private getSectionBySectionId(){
      this.sectionService.getSection( this.sectionID ).subscribe(
          (response: any) => {
            this.selectedSection = response.body.message;
          },
          (error: any) => {
            console.error( error );
          }
      )
  }


  ngOnInit(){}


}
