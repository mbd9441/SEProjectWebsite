import { Component, OnInit, Input, OnDestroy, Inject } from '@angular/core';
import { Device } from '../Device';
import { DeviceRequest } from '../DeviceRequest';
import { DeviceService } from '../device.service';
import { DeviceApproval } from '../DeviceApproval';
import { Subscription, BehaviorSubject } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Section } from 'src/app/client/Section';
import { SectionDataSource } from '../../client/section.data-source'
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { NumberAttributeConstraintsType } from 'aws-sdk/clients/cognitoidentityserviceprovider';
import { SectionService } from 'src/app/client/section.service';
import { HttpClient } from '@angular/common/http';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeviceRequestListComponent } from './device-request-list.component';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'approval-form',
  templateUrl: './approval-form.component.html',
  styleUrls: ['../devices.component.css']
})

export class ApprovalFormComponent implements OnInit {

    valid: boolean = true;
    approvalData: DeviceApproval;
    request: DeviceRequest;
    selectedSection: Section;
    sections: Section[];
    clientID: number;
    sectionID: number;
    userRole: number;
    devicename: string;
    sectionDataSource: SectionDataSource;
    
    constructor(private deviceService: DeviceService, private authService: AuthService, sectionService: SectionService,
        public dialogRef: MatDialogRef<DeviceRequestListComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
            this.approvalData = new DeviceApproval();
            this.sectionDataSource = new SectionDataSource( sectionService );
            this.sectionDataSource.SectionData.subscribe( (section: Section[]) => this.sections = section  );
            this.selectedSection = new Section();
            this.getAttributes().then(
                result => {
                  this.sectionDataSource.loadSectionsByClient(this.clientID);
                }
            );
        }

    ngOnInit() {
        this.request=this.data.request;
    }


    onSubmit( event ){
        event.preventDefault();
        this.approveRequest();
    }

    onCancel( event: any ){
        event.preventDefault();
        this.dialogRef.close();
        
    }

    private approveRequest(){
        console.log(this.selectedSection, this.selectedSection.section_id)
        console.log(this.approvalData)
        this.approvalData.section_id = this.selectedSection.section_id;
        this.approvalData.client_id = this.request.device.client_id;
        this.approvalData.instance_id = this.request.device.instance_id;
        this.approvalData.name=this.request.device.name;
        const deviceID: number  = this.request.device.device_id;
        console.log(this.approvalData)
        this.deviceService.approveDevice( deviceID, this.approvalData )
            .subscribe( response => {
                if (response.ok){
                    this.valid = true;
                    this.dialogRef.close();
                }
                else {
                    this.valid = false;
                }
            },
              error => {
                  this.valid = false;
              } 
        );  
    }

    async getAttributes(){
        const attributes = await this.authService.getAttributes();
        this.clientID = attributes["custom:client_id"];
        this.sectionID = attributes["custom:section_id"];
        this.userRole = attributes["custom:role"];
      }
}
