import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {AuthService} from '../auth/auth.service';
import {UserTypes} from "../user/users/User";
import {Router} from "@angular/router";

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
    @Output() public sidenavToggle = new EventEmitter();
    userRole: string ='';
    types: any = UserTypes;
    constructor(public authService:AuthService, private router:Router) { }

    ngOnInit() {
        this.getUserRole();
    }

    toggleSidenav(){
        this.sidenavToggle.emit();
    }

    navigate(route: string){
        this.router.navigate([route]);
    }

    async getUserRole(){
        const role = await this.authService.getUserRole();
        this.userRole = role;
    }

}
