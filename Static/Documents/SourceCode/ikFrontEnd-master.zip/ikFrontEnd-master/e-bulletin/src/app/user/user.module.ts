import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {UserComponent} from "./user.component";
import {UserListComponent} from "./user-list.component";
import {UserDetailComponent} from "./user-detail.component";
import {UserRoutingModule} from "./user-routing.module";
import {
  MatButtonModule, MatDialogModule, MatFormFieldModule,
  MatIconModule, MatInputModule,
  MatProgressSpinnerModule, MatSelectModule,
  MatTableModule, MatTabsModule
}
  from "@angular/material";
import {FlexLayoutModule} from "@angular/flex-layout";
import {NavbarModule} from "../navbar/navbar.module";
import {NewUserFormComponent} from "./new-user.component";
import {FormsModule} from "@angular/forms";

@NgModule({
  declarations: [
    UserComponent,
    UserListComponent,
    UserDetailComponent,
    NewUserFormComponent
  ],
  imports: [
      CommonModule,
      UserRoutingModule,
      MatTableModule,
      MatIconModule,
      MatButtonModule,
      MatProgressSpinnerModule,
      MatTabsModule,
      MatDialogModule,
      MatFormFieldModule,
      MatInputModule,
      MatSelectModule,
      FormsModule,
      FlexLayoutModule,
      NavbarModule
  ],
  entryComponents: [NewUserFormComponent]
})
export class UserModule { }
