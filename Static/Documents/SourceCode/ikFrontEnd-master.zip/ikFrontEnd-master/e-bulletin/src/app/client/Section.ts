export class Section {
    section_id: number;
    section_name!: string;
    client_id!: number;

    constructor( id:number = null, name: string = null, clientID: number = null){
        this.section_id = id;
        this.section_name = name;
        this.client_id = clientID;
    }
}
