import { OnInit, Component } from "@angular/core";


@Component({
    selector: 'content-request-success',
    templateUrl: './content-request-success.component.html',
    styleUrls: ['../content.component.css']
  })

export class ContentRequestSuccessComponent implements OnInit {
    title: string = "It's on the way";
    constructor(){}

    ngOnInit(){}
    
}