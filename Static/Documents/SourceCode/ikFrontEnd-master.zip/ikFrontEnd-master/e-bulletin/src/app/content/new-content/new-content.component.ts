import {Component, OnInit, Inject} from "@angular/core";
import { ContentService } from "../content.service";
import { Content } from "../Content";
import { AuthService } from "src/app/auth/auth.service";
import { Router } from "@angular/router";
import { ContentListComponent } from "../content-list/content-list.component";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'new-content',
  templateUrl: './new-content.component.html',
  styleUrls: ['../content.component.css']
})

export class NewContentFormComponent implements OnInit {

  content: Content;
  valid: boolean = true;
  userRole: string;
  clientID: number;
  sectionID:number;

  constructor(private contentService: ContentService, private authService: AuthService,
    private router: Router, public dialogRef: MatDialogRef<ContentListComponent>, @Inject(MAT_DIALOG_DATA) public data: any){
      this.content = new Content();
      this.addContent = this.addContent.bind(this);
      this.onSubmit = this.onSubmit.bind(this);
      this.getAttributes();
  }

  ///another is a boolean, default is false, onAntoher passes in True to allow the
  ///function to know to clear the page
  private addContent(another=false): void {
      const user = this.authService.getUser();
      this.content.status = "Reserved";
      this.content.submitter = user ? user.username: "";
      this.content.client_id = this.clientID;
      this.content.section_id = this.sectionID;

      this.contentService.createContent(this.content).subscribe(
          ( result: any ) => {
              console.log( result );
              if ( result.status === 200 ) {
                  this.valid = true;
                  console.log( another );
                  if ( another ) {
                    this.content.title='';
                    this.content.description='';
                    this.content.content='';
                  }
                  else {
                    this.dialogRef.close();
                  }
                  this.data.reload();
              }
              else {
                this.valid = false;
              }
          },
          ( error ) => {
              console.error( error );
              this.valid = false;
          }
      );
  }

  onSubmit(event){
      event.preventDefault();
      this.addContent();
  }

  onAnother(event){
    event.preventDefault();
    this.addContent(true);
  }

  ngOnInit(){}

  onCancel( event: any ){
      event.preventDefault();
      this.dialogRef.close();
  }


  async getAttributes(){
    var attributes = await this.authService.getAttributes();
    this.clientID= attributes["custom:client_id"];
    this.sectionID= attributes["custom:section_id"];
    this.userRole = attributes["custom:role"];
  }


}
