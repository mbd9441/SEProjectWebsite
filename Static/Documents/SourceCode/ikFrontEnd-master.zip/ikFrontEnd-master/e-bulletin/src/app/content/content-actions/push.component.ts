import { config } from './../../config/config';
import {Component, OnInit, Input } from "@angular/core";
import * as AWS from 'aws-sdk';
import { IContent } from "../IContent";
import { DeviceContent } from '../device-content';
import { ContentService } from "../content.service";
import { AuthService } from "src/app/auth/auth.service";
import { Router } from "@angular/router";
import { DeviceService } from 'src/app/devices/device.service';
import { Device } from 'src/app/devices/Device';

@Component({
    selector: 'push-content',
    templateUrl: './push.component.html',
    styleUrls: ['../content.component.css']
})

export class PushComponent implements OnInit{
    @Input() content: IContent
    deviceContent: DeviceContent
    devices: Device[];
    valid: boolean = true;
    selectedDevice: Device;
    disabled: boolean = true;

    constructor(private contentService: ContentService, private deviceService: DeviceService, private router: Router){
        this.selectedDevice = new Device();
        this.loadDevices();
        this.deviceContent = new DeviceContent();
        this.onSubmit = this.onSubmit.bind(this);
    }

    onSubmit( ev ): void {
        ev.preventDefault();
        this.pushContent();
    }

    onSelect( device: Device ): void {
        this.selectedDevice = device;
        this.disabled = false;
        console.log("here");
    }

    ngOnInit(){}

    private loadDevices(): void {
        this.deviceService.getDevices().subscribe(
            ( response: any ) => {
                if ( response.ok ){
                    this.devices = response.body.message.filter(
                        (device: Device) => device.status === "Approved"
                    );
                }
            }
        )
    }

    private pushContent(): void {
        const topic_name = this.selectedDevice.topic_name;
        this.deviceContent.device_id = this.selectedDevice.device_id;
        this.deviceContent.content_id = this.content.content_id;

        this.contentService.pushContent({topic_name:topic_name, ...this.deviceContent }).subscribe(
            ( result: any ) => {
                console.log(result);
                if ( result.status === 200 ) {
                    this.valid = true;
                    this.disabled = true;
                }
                else {
                  this.valid = false;
                }
            },
            ( error ) => {
                console.error( error );
                this.valid = false;
            }
        );
    }


}
