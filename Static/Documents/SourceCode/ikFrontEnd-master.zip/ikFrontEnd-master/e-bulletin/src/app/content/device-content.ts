
export class DeviceContent implements DeviceContent{

    content_id: number;
    device_id: number;
    time_published;
    is_active: boolean;
    is_saved: boolean;

    constructor(content_id = null, device_id = null, time_published = null, is_active = null, is_saved= null){
        this.content_id = content_id;
        this.device_id = device_id;
        this.time_published = time_published;

        this.is_active = is_active === 1;
        this.is_saved = is_saved === 1;
    }

}
