import {Component, EventEmitter, Input, OnInit, Output, DoCheck} from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @Input()
  email: string;

  username: string;

  password: string;


  @Output()
  submitted: EventEmitter<any> = new EventEmitter();

  constructor() { }

  onSubmit( e ):void{
      e.preventDefault();
      this.submitted.emit({email: this.email, username: this.username, password: this.password});
  }

  ngOnInit() {}


}
