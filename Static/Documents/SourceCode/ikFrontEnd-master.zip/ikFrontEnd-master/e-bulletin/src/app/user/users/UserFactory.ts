import User from "./User";
import ClientUser from "./ClientUser";
import SectionUser from "./SectionUser";
import SysAdmin from "./SysAdmin";
import UsernameAttribute from "../attributes/UsernameAttribute";
import EmailAttribute from "../attributes/EmailAttribute";
import {CognitoUserObj} from "./CognitoUserType";
import CognitoAttribute from "../attributes/CognitoAttributeType";
import {ClientService} from "../../client/client.service";
import {SectionService} from "../../client/section.service";





export default class UserFactory {

    constructor( private clientService: ClientService, private sectionService: SectionService ){}

    public createUser( cognitoUser: CognitoUserObj, role: string ): User {
        const attributes: CognitoAttribute[] = cognitoUser.Attributes;
        let user: User;
        // create the type of user
        switch( role ){
            case 'Client-Account-Administrator':
              user = new ClientUser( this.clientService );
              break;
            case 'Client-Account-Owner':
                user = new ClientUser( this.clientService );
                user.owner = true;
                break;
            case 'Section-Administrator':
                user = new SectionUser( this.clientService, this.sectionService );
                break;
            case 'System-Administrator':
                user = new SysAdmin();
                break;
        }
        // assign the username and the correct account status
        user.userName = new UsernameAttribute(cognitoUser.Username);
        if ( cognitoUser.UserStatus === 'CONFIRMED' ){
            user.isConfirmed = true;
        }

        // go through the attribute list and
        attributes.forEach( (attribute: CognitoAttribute) => {

            if(  attribute.Name === 'custom:client_id' && !( user instanceof SysAdmin ) ){
                // console.log( +attribute.Value );
                user.setClientID( +attribute.Value );

            }
            else if ( attribute.Name === 'custom:section_id' && ( user instanceof SectionUser ) ){
                user.setSectionID( +attribute.Value );
            }

            else if (  attribute.Name === 'email' ){
                user.email = new EmailAttribute( attribute.Value );
            }

        });
        return user;
    }

}
