import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {config} from "../config/config"
import {Auth} from 'aws-amplify';

const { AuthenticationDetails, CognitoUserPool, CognitoUser, CognitoUserAttribute } = require('amazon-cognito-identity-js');

@Injectable({
  providedIn: 'root'
})

export class AuthService {
    // TODO: replace with BizCloud's user pool id and client id
    poolData = {
        UserPoolId : config.cognito.userPoolId,
        ClientId : config.cognito.userPoolClientId
    };
    constructor(private http: HttpClient, private router:Router){
        this.authenticate = this.authenticate.bind(this);
        this.isAuthenticated = this.isAuthenticated.bind(this);
        this.logout = this.logout.bind(this);
    }

    authenticate(authData: any): Promise<string> {
        return new Promise( ( resolve, reject ) => {
            const authenticationDetails = new AuthenticationDetails(authData);
            const userPool = new CognitoUserPool(this.poolData);
            const userData = {
                Username : authData.Username,
                Pool : userPool
            };

            const cognitoUser = new CognitoUser(userData);
            if( cognitoUser != null ) {
                cognitoUser.authenticateUser(authenticationDetails, {
                  onSuccess: (result) => {
                    const accessToken: string = result.getAccessToken().getJwtToken();

                    /* Use the idToken for Logins Map when Federating User Pools with identity pools or when passing through an Authorization Header to an API Gateway Authorizer*/
                    const idToken = result.idToken.jwtToken;
                    resolve(accessToken);
                  },

                  onFailure: function (err) {
                    if ( err.code === "UserNotFoundException"){
                        this.logout();
                    }
                    console.error(err);
                    reject(err);
                  },
                });
            }
            else {
                this.logout();
            }
        });


    }

    private async createSession(user: any){
        const authenticated = await this.isAuthenticated();
        if ( this.isAuthenticated() ){
            localStorage.setItem('currUser', JSON.stringify(user))
        }
    }

    async isAuthenticated(): Promise<boolean> {
        return new Promise<boolean>( (resolve, reject) => {
            const cognitoUser = this.getUser();
            if (cognitoUser != null) {
                cognitoUser.getSession(function( err, session) {
                    if ( err ) {
                        if ( err.code === "UserNotFoundException" ){
                            cognitoUser.signOut();
                        }
                        reject( err );
                    }
                    else {
                      const valid: boolean = session.isValid();
                      resolve(valid);
                    }
                });
            }
            else {
                console.log('no current user');
                resolve(false);
            }
        });
    }

    getUser(){
        const userPool = new CognitoUserPool(this.poolData);
        return userPool.getCurrentUser();
    }

    signUp(userData: any){
        return new Promise<Object>(  (resolve, reject) => {

            const userPool = new CognitoUserPool(this.poolData);

            let attributeList = [];

            const emailData = {
                Name: 'email',
                Value: userData.email.trim()
            };

            const roleData = {
              Name: 'custom:role',
              Value: userData.role.trim()
            };


            const emailAttribute = new CognitoUserAttribute( emailData );
            const roleAttribute = new CognitoUserAttribute( roleData );
            attributeList.push( emailAttribute );
            attributeList.push( roleAttribute );

            if( userData.client_id !== null  ) {
              const clientData = {
                Name: 'custom:client_id',
                Value: userData.client_id.toString()
              };
              const clientAttribute = new CognitoUserAttribute(clientData);
              attributeList.push(clientAttribute);
            }
            if (userData.section_id !== null ) {
              const sectionData = {
                Name: 'custom:section_id',
                Value: userData.role.trim()
              };
              const sectionAttribute = new CognitoUserAttribute( sectionData );
              attributeList.push(sectionAttribute);
            }

            userPool.signUp(userData.username.trim(), userData.password.trim(), attributeList, null,
                (err, result) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(result.user);
                }
            );
        });
    }

    confirmUser( username: string, confirmationCode: string){

        return new Promise<Object>( (resolve, reject) => {
            const userPool = new CognitoUserPool(this.poolData);
            const userData = {
              Username: username,
              Pool: userPool
            };

            const cognitoUser = new CognitoUser(userData);
            cognitoUser.confirmRegistration(confirmationCode, true, function (err, result) {
                if ( err ) {
                    reject(err);
                }
                else {
                    resolve( result );
                }
            });
        });
    }

    resendConfirmationCode(username){

        return new Promise<Object>( (resolve, reject) => {
            const userPool = new CognitoUserPool(this.poolData);
            const userData = {
                Username: username,
                Pool: userPool
            };

            const cognitoUser = new CognitoUser(userData);
            cognitoUser.resendConfirmationCode(function(err, result) {
                if (err) {
                    reject( err );
                }
                resolve(result);
            });
        });

    }


    async getAttributes(): Promise<Object>{
        return new Promise<Object>( (resolve, reject) => {
            const cognitoUser = this.getUser();
            let attributes = {};
            if (cognitoUser!=null){
                Auth.userAttributes(cognitoUser)
                .then(data => (
                  data.filter(
                    ( attribute ) => (
                      attribute.getName().includes('client') || attribute.getName().includes('section')
                      || attribute.getName().includes('role')
                    )
                  ))
                )
                .then(
                    data => {
                        data.forEach(attribute => attributes[attribute.getName()] = attribute.getValue());
                        console.log(attributes);
                        resolve(attributes);
                    }
                );
            }
        })
    }

    async getUserRole(){
      const attributes = await this.getAttributes();
      return attributes['custom:role'];
    }

    async getUserClientId(){
      const attributes = await this.getAttributes();
      return attributes['custom:client_id'];
    }

    async getUserSectionId(){
      const attributes = await this.getAttributes();
      return attributes['custom:section_id'];
    }

    public logout(): void{
        const cognitoUser = this.getUser();
        if ( cognitoUser != null ){
            cognitoUser.signOut();
        }
        localStorage.removeItem('currUser');
        this.router.navigate(['']);
    }
}
