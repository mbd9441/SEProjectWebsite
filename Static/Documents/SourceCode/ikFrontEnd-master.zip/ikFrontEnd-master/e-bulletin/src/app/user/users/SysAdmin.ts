import User from "./User";
import EmailAttribute from "../attributes/EmailAttribute";
import UsernameAttribute from "../attributes/UsernameAttribute";

export default class SysAdmin implements User {

    email: EmailAttribute;
    userName: UsernameAttribute;
    isConfirmed: boolean = false;
    clientID = null;
    sectionID = null;

}
