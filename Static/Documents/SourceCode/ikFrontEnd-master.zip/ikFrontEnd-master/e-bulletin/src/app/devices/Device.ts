export class Device {
    device_id: number;
    name: string;
    topic_name: string;
    section_id: number;
    client_id!: number;
    instance_id!: string;
    status!: string;
}