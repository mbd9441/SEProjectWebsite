import { Device } from "./Device";

export class DeviceRequest {
    device: Device;
    client_name: string;


    constructor( device: any | Device = null, client_name: string="" ){
        this.device = device;
        this.client_name = client_name;
        console.log( this.device, this.client_name, this.device.client_id)

        if (!this.device.name){
            this.device.name="[No Name]"
        }
    }
}