export default interface CognitoAttribute {
    Name: string,
    Value: string
}
