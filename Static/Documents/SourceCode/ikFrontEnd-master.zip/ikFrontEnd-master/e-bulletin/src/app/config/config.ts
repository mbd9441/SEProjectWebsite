export const config = {
    cognito: {
        userPoolId: 'us-east-1_yRtsJkGqc', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '5o2b2skqvou28aucgsatgetpim', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1', // e.g. us-east-2
        indentityPoolId: 'us-east-1:9ebfcb40-cb15-4a14-ab4c-5ec30f293257'
    },
    api: {
        invokeUrl: 'https://34a1ei3v53.execute-api.us-east-1.amazonaws.com/registration/',
        // invokeUrl: 'https://lvtsme4ili.execute-api.us-east-1.amazonaws.com/master/' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    },
    iot: {
        policyName: 'InfoKioskPolicy',
        endpoint: 'akfhq5zfyp890-ats.iot.us-east-1.amazonaws.com'
    }
};
