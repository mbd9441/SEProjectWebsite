import { OnInit, Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Device } from "src/app/devices/Device";
import { DeviceService } from "src/app/devices/device.service";
import { ContentService } from "../content.service";
import { Content } from "../Content";
import { ClientService } from "src/app/client/client.service";
import { Client } from "src/app/client/Client";

@Component({
    selector: 'content-request-form',
    templateUrl: './content-request-form.component.html',
    styleUrls: ['../content.component.css']
  })

export class ContentRequestFormComponent implements OnInit {

    device: Device;
    contentRequest: Content;
    valid: boolean = true;
    client: Client;
    constructor( private route: ActivatedRoute, private router: Router,
        private clientService: ClientService, private deviceService: DeviceService, 
        private contentService: ContentService ){
        this.contentRequest = new Content();
        this.client = { client_name: "" };
        this.device = new Device();
    }

    ngOnInit(){
        this.route.params.subscribe( params => {
            if( params['deviceID']){
                this.contentRequest.device_id = +params['deviceID'];
                this.loadDevice();
            }

            if( params['clientID'] ){
                this.contentRequest.client_id = +params['clientID'];
                this.loadClient();
            }
        })
    }
    onSubmit( event:any ): void {
        event.preventDefault();
        this.submitContentRequest();
    }

    private submitContentRequest(): void {
        this.contentService.requestContent(this.contentRequest).subscribe(
            ( response:any ) => {
                if( !response.ok ){
                    this.valid = false;
                }
                else{
                    this.valid = true;
                    this.router.navigate(['/content/success']);
                }
            },
            ( error: any ) => {
                console.error( error );
                this.valid = false;
            }
        )
    }

    private loadDevice(): void {
        this.deviceService.getDevice(this.contentRequest.device_id).subscribe(
            (response: any) => {
                if( response.ok ){
                    this.device = response.body.message;
                }
            },
            ( error: any ) => console.error( error )
        )
    }

    private loadClient(): void {
        this.clientService.getClientById(this.contentRequest.client_id).subscribe(
            ( response: any ) => {
                if ( response.ok ){
                    this.client = response.body.message;
                }
            },
            ( error: any ) => {
                console.error( error );
            }
        )
    }
}
