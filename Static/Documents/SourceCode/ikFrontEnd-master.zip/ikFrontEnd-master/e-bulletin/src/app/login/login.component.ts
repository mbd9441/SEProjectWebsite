import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {HttpClient} from "@angular/common/http";
import {AuthService} from "../auth/auth.service";
import {UserTypes} from "../user/users/User";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  userRole='';
  username: string = "";
  password: string = "";
  valid: boolean;
  constructor(private router: Router, private authService: AuthService) {
      this.valid = true;
  }

  async onSubmit() {

      const authInfo = {Username: this.username.trim(), Password: this.password.trim()};
      await this.authService.authenticate(authInfo).then(
          async (result) => {
              console.log(result);
              if ( result ) {
                  const isAdmin: boolean = await this.getUserRole() == UserTypes.SYS_ADMIN;
                  if ( isAdmin ) {
                      this.router.navigate(['client']);
                  }
                  else {
                      this.router.navigate(['content']);
                  }
              }
              else {
                  this.valid = false;
              }
        })
        .catch(
            (error) => {
                if ( error.code === "UserNotConfirmedException" ){
                    this.router.navigate(['confirm']);
                }
                else {
                    console.error(error);
                    this.valid = false;
                }
            }
        )

  }
  ngOnInit() {
    this.getUserRole();
  }

  async getUserRole(){
    const role= await this.authService.getUserRole();
    this.userRole=role;
    return role;
  }

}
