import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { ContentService } from "./content.service";
import { Observable, BehaviorSubject } from "rxjs";
import { Content } from "./Content";
import { catchError } from 'rxjs/operators';
import { of } from "zen-observable";
import {DeviceContent} from "./device-content";

export class ContentDataSource implements DataSource<Content> {

    private contentSubject = new BehaviorSubject<Content[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);

    public loading = this.isLoading.asObservable();
    public contentData = this.contentSubject.asObservable();
    constructor( private contentService: ContentService ){ }

    public connect( collectionViewer: CollectionViewer ): Observable<Content[]> {
        return this.contentSubject.asObservable();
    }

    public disconnect( collectionViewer: CollectionViewer ): void {
        this.contentSubject.complete();
        this.isLoading.complete();
    }

    public loadContents (): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.contentService.getContents()
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.contentSubject.next( result.body.message );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadContentsByClient (id: number): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.contentService.getContentsByClient(id)
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.contentSubject.next( result.body.message );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadContentsBySection (id: number): void {
        this.isLoading.next(true),
        console.log(id)
        setTimeout( () =>
            this.contentService.getContentsBySection(id)
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.contentSubject.next( result.body.message );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadContentRequests (): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.contentService.getPendingContent()
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        var contentProps=Object.keys(result.body.message)
                        var contentArray=[];
                        for (let prop of contentProps){
                            contentArray.push(result.body.message[prop])
                        }
                        this.contentSubject.next( contentArray );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadContentRequestsByClient (id: number): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.contentService.getPendingContentByClient(id)
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        var contentProps=Object.keys(result.body.message)
                        var contentArray=[];
                        for (let prop of contentProps){
                            contentArray.push(result.body.message[prop])
                        }
                        this.contentSubject.next( contentArray );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

    public loadContentRequestsBySection (id: number): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.contentService.getPendingContentBySection(id)
                .pipe(
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe(
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        var contentProps=Object.keys(result.body.message)
                        var contentArray=[];
                        for (let prop of contentProps){
                            contentArray.push(result.body.message[prop])
                        }
                        this.contentSubject.next( contentArray );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }
                )
            ,3000
        )
    }

}
