import { Component, OnInit, Input, Inject } from '@angular/core';
import { Section } from '../Section';
import { SectionService } from '../section.service';
import { ActivatedRoute } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SectionListComponent } from '../section-list/section-list.component';

@Component({
  selector: 'section-detail',
  templateUrl: './section-detail.component.html',
  styleUrls: ['../client.css']
})

export class SectionDetailComponent implements OnInit {
  @Input() 
  section: Section;
  sectionID: number;
  currName: any;
  constructor(private sectionService: SectionService,private route: ActivatedRoute,
    public dialogRef: MatDialogRef<SectionListComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.section = this.data.section;
  }

  loadSection(){
    this.sectionService.getSection( this.sectionID ).subscribe(
        ( response: any ) => {
            if( response.ok ){
                this.section = response.body.message;
            }
        },
        ( error: any ) => console.log(error)
    );
  }

  onCancel( event: any ){
    event.preventDefault();
    this.dialogRef.close();
  }

}
