import { config } from './../config/config';
import { Component, OnInit } from '@angular/core';
import {AuthService} from "../auth/auth.service";
import {ActivatedRoute, Router} from "@angular/router";
import {UserService} from "../user/user.service";
const {CognitoUserPool, CognitoUserAttribute} = require('amazon-cognito-identity-js');

@Component({
  selector: 'admin-new',
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css']
})

export class AdminRegistrationComponent implements OnInit {

    // TODO: replace with BizCloud's user pool id and client id
    valid: boolean = true;
    email: string = "";
    verified: boolean = false;
    role:string;
    clientID: number = null;
    sectionID: number = null;
    loaded = false;
    constructor(private authService: AuthService,
                private userService: UserService,
                private router: Router,
                private route: ActivatedRoute
                ) { }

    async onSubmit( userData ) {
        userData.role = this.role;

        userData.client_id = this.clientID;
        userData.section_id = this.sectionID;

        await this.authService.signUp( userData )
        .then(
            (result) => {
                this.router.navigate(['confirm']);
                this.valid = true;
            }
        )
        .catch(
            ( error ) => {
                console.error(error);
                this.valid=false
            }
        );
    }

    ngOnInit() {
      this.route.params.subscribe( params => {
        console.log(params);
        this.email = params['email'];
        this.checkVerification();
      });
    }

    checkVerification(){
        this.userService.verifyEmail(this.email).subscribe(
          ( response: any ) => {
            if( response.ok){
              const data = response.body.message;
              this.verified = data.valid;
              this.email = data.invite.email;
              console.log(data);
              this.role = data.invite.role;
              this.clientID = data.invite.client_id;
              this.sectionID = data.invite.section_id;
              this.loaded = true;
            }
          }
        );
    }

}
