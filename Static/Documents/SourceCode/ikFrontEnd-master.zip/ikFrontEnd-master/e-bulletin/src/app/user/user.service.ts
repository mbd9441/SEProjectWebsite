import { Injectable } from '@angular/core';
import {HttpClient, HttpResponse} from "@angular/common/http";
import {Observable} from "rxjs";
import {CognitoUserObj} from './users/CognitoUserType';
import {config} from "../config/config";
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

    getUsers(): Observable<HttpResponse<CognitoUserObj[]>> {
        return this.http.get<CognitoUserObj[]>(config.api.invokeUrl+'users', {observe: 'response'});
    }

    getUsersByClient( clientID: number ): Observable<HttpResponse<CognitoUserObj[]>>{
        return this.http.get<CognitoUserObj[]>(config.api.invokeUrl+`users/client/${clientID}`, {observe: 'response'});
    }

    getUsersBySection( sectionID: number ): Observable<HttpResponse<CognitoUserObj[]>>{
        return this.http.get<CognitoUserObj[]>(config.api.invokeUrl+`users/section/${sectionID}`, {observe: 'response'});
    }

    sendInvitation( inviteData: any ){
        return this.http.post<any>(config.api.invokeUrl+'users/invite',inviteData, {observe: 'response'});
    }

    verifyEmail( email:string ){
        return this.http.get<any>(config.api.invokeUrl+ 'users/verify/'+email, {observe: 'response'});
    }
}
