import {Component, Input, OnInit} from '@angular/core';
import User from "./users/User";
import {UserDataSource} from "./user.data-source";
import {UserService} from "./user.service";
import {ClientService} from "../client/client.service";
import {SectionService} from "../client/section.service";
import {AuthService} from "../auth/auth.service";
import {MatDialog} from "@angular/material";
import {NewUserFormComponent} from "./new-user.component";

@Component({
  selector: 'user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user.component.css']
})
export class UserDetailComponent implements OnInit {

  @Input() role: string;
  users: User[];
  dataSource: UserDataSource;
  tableColumns: string[];
  constructor(public modal: MatDialog,
              private userService: UserService,
              private clientService: ClientService,
              private sectionService: SectionService,
              private authService: AuthService) {
    this.tableColumns = ["username", "email", "status"];

    this.dataSource = new UserDataSource( this.userService, this.clientService,
      this.sectionService, this.authService );
    this.dataSource.userData.subscribe( users => this.users = users );
  }

  ngOnInit() {
    this.dataSource.loadUsers( this.role );
    if ( !this.role.includes('System') ){
        this.tableColumns.push("client");
    }
    if ( this.role.includes('Section') ){
        this.tableColumns.push("section");
    }

  }

  openModal(): void {
      this.modal.open( NewUserFormComponent, {
        width: '50%',
      });
  }

}
