import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { Observable, BehaviorSubject } from "rxjs";
import { catchError } from 'rxjs/operators';
import { of } from "zen-observable";
import {CognitoUserObj} from "./users/CognitoUserType";
import CognitoAttribute from "./attributes/CognitoAttributeType";
import UserFactory from "./users/UserFactory";
import User, {UserTypes} from "./users/User";
import {UserService} from "./user.service";
import SysAdmin from "./users/SysAdmin";
import ClientUser from "./users/ClientUser";
import SectionUser from "./users/SectionUser";
import {ClientService} from "../client/client.service";
import {SectionService} from "../client/section.service";
import {AuthService} from "../auth/auth.service";
import {Auth} from 'aws-amplify';

export class UserDataSource implements DataSource<User> {

  private userSubject = new BehaviorSubject<User[]>([]);
  private isLoading = new BehaviorSubject<boolean>(false);
  private userFactory: UserFactory;
  private userRole: string;
  public loading = this.isLoading.asObservable();
  public userData = this.userSubject.asObservable();

  constructor( private userService: UserService, private clientService: ClientService,
               private sectionService: SectionService, private authService: AuthService ){
      this.userFactory = new UserFactory(this.clientService, this.sectionService);

  }

  public connect( collectionViewer: CollectionViewer ): Observable<User[]> {
    return this.userSubject.asObservable();
  }

  public disconnect( collectionViewer: CollectionViewer ): void {
    this.userSubject.complete();
    this.isLoading.complete();
  }

    public loadUsers( role: string ): void{

        this.isLoading.next(true);



        setTimeout( async () => {
            this.userRole = await this.authService.getUserRole();

            switch (this.userRole) {
                case UserTypes.CLI_ACC_OWNER:
                case UserTypes.CLI_ACC_ADMIN:
                    await this.getAllUsersInClient( role );
                    break;
                case UserTypes.SEC_ADMIN:
                    await this.getAllUsersInSection( );
                    break;
                default:
                    this.getAllUsers( role );
                    break;
            }

        },1000
        )
    }

    getAllUsers( role: string ){
        this.userService.getUsers()
        .pipe(
            catchError( error => {
              console.error(error);
              return of([]);
            })
        )
        .subscribe(
            ( response:any ) => {
                const users: User[] = response.body.message
                .map(
                    ( user: CognitoUserObj ) => this.createUser( user )
                )
                .filter(
                    (user: User) => this.filterUser( role, user )
                );

                this.userSubject.next( users );
                this.isLoading.next( false );
            },
            ( error ) => {
                if ( error){
                  console.error( error );
                }
            }
        )
    }

    async getAllUsersInClient(role: string){
        const clientID = await this.authService.getUserClientId( );
        this.userService.getUsersByClient( clientID )
        .pipe(
            catchError( error => {
              console.error(error);
              return of([]);
            })
        )
        .subscribe(
              ( response:any ) => {
                  const users: User[] = response.body.message
                  .map(
                      ( user: CognitoUserObj ) => this.createUser( user )
                  )
                  .filter(
                      ( user: User ) => this.filterUser( role, user )
                  );
                  this.userSubject.next( users );
                  this.isLoading.next( false );
              },
              ( error ) => {
                  if ( error){
                    console.error( error );
                  }
              }
        );
    }


    async getAllUsersInSection( ){
        const sectionID = await this.authService.getUserSectionId();


        this.userService.getUsersBySection(sectionID)
        .pipe(
          catchError(error => {
            console.error(error);
            return of([]);
          })
        )
        .subscribe(
          (response: any) => {
            const users: User[] = response.body.message
            .map(
              (user: CognitoUserObj) => this.createUser(user)
            )
            .filter(
              (user: User) => this.filterUser(UserTypes.SEC_ADMIN, user)
            );

            this.userSubject.next(users);
            this.isLoading.next(false);
          },
          (error) => {
            if (error) {
              console.error(error);
            }
          }
        );


    }

    createUser( user: CognitoUserObj ): User{
        const role = user.Attributes.find(
            ( attribute: CognitoAttribute ) => attribute.Name === "custom:role"
        );

        return this.userFactory.createUser(user, role.Value);
    }

    filterUser(role: string, user: User): boolean {
        switch (role) {
            case UserTypes.CLI_ACC_ADMIN:
                return ((user instanceof ClientUser) && (!user.owner));
            case UserTypes.CLI_ACC_OWNER:
                return ((user instanceof ClientUser) && (user.owner));
            case UserTypes.SEC_ADMIN:
                return user instanceof SectionUser;
            default:
                return user instanceof SysAdmin;
        }
    }

}
