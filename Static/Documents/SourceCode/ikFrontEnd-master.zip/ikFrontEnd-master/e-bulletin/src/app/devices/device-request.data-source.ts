import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { DeviceService } from "./device.service";
import { Observable, BehaviorSubject } from "rxjs";
import {AuthService} from "../auth/auth.service";
import { DeviceRequest } from "./DeviceRequest";
import { SectionService } from "../client/section.service";

export class DeviceRequestDataSource implements DataSource<DeviceRequest> {

    private requestSubject = new BehaviorSubject<DeviceRequest[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);

    public loading = this.isLoading.asObservable();
    public requestData = this.requestSubject.asObservable();
    private userRole: number;
    private clientID: number;
    private sectionID: number;
    constructor( private deviceService: DeviceService, private authService: AuthService, private sectionService: SectionService ){ }

    public connect( collectionViewer: CollectionViewer ): Observable<DeviceRequest[]> {
        return this.requestSubject.asObservable();
    }

    public disconnect( collectionViewer: CollectionViewer ): void {
        this.requestSubject.complete();
        this.isLoading.complete();
    }
  
    private loadDeviceRequests(): void {
      this.deviceService.getPendingDevices().subscribe(
        ( result: any ) => {
          if ( result.ok ){
            this.requestSubject.next(result.body.message.map( ({client_name, ...device}) => (new DeviceRequest( device, client_name ))) );
            this.isLoading.next( false );
          }
        },
        ( error: any  ) => {
          if( error ){
            console.log( error );
          }
        }
      )
  }

  private loadDeviceRequestsByClient(id: number): void {
    this.deviceService.getPendingDevicesByClient(id).subscribe(
      ( result: any ) => {
        if ( result.ok ){
          console.log(result.body.message)
          this.requestSubject.next(result.body.message.map( ({client_name, ...device}) => (new DeviceRequest( device, client_name ))) );
          this.isLoading.next( false );
        }
      },
      ( error: any  ) => {
        if( error ){
          console.log( error );
        }
      }
    )
  }

  async loadDevicesByRole(){
    await this.getAttributes();
    if (this.clientID){
      this.loadDeviceRequestsByClient(this.clientID);
      console.log("client")
    } else {
        this.loadDeviceRequests();
        console.log("admin")
    }
}

  async getAttributes(){
    const attributes = await this.authService.getAttributes();
    this.userRole = attributes["custom:role"];
    this.clientID = attributes["custom:client_id"];
    this.sectionID = attributes["custom:section_id"];
}
}
