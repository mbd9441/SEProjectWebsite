import {Component, OnInit, NgModule, Inject, Input} from "@angular/core";
import { ClientService } from "../client.service";
import { Client } from "../Client";
import { AuthService } from "src/app/auth/auth.service";
import { Router } from "@angular/router";
import { ActivatedRoute } from '@angular/router';
import { Section } from '../Section';
import { SectionService } from '../section.service';
import { FormsModule } from "@angular/forms";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { SectionListComponent } from "../section-list/section-list.component";
import { ClientDataSource } from "../client.data-source";

@NgModule({
  imports: [FormsModule],
})

@Component({
  selector: 'new-section',
  templateUrl: './new-section.component.html',
  styleUrls: ['../client.css']
})

export class NewSectionFormComponent implements OnInit {
  @Input() 
  clientID: number;
  currentClient: Client;
  clients: Client[] = [];
  sectionID: number;
  userRole: string;
  newSection:Section = new Section();
  valid: boolean = true;
  clientDataSource: ClientDataSource;
  addSectionHeader="Add Section"


  constructor(private SectionService: SectionService, private clientService: ClientService, private authService: AuthService, private router: Router, private route: ActivatedRoute,
      public dialogRef: MatDialogRef<SectionListComponent>, @Inject(MAT_DIALOG_DATA) public data: any){
      this.clientDataSource = new ClientDataSource( this.clientService );
      this.clientDataSource.clientData.subscribe( (client: Client[]) => this.clients = client  );
      this.onSubmit = this.onSubmit.bind(this);
  }

  ngOnInit() {
    this.clientDataSource.loadClients()
    this.clientID=this.data.id;
    this.getAttributes();
    if (this.clientID){
      this.loadClient();
    } else {
      this.currentClient = new Client();
    }
  }

  onSelect(client:Client): void {
    console.log(this.currentClient, client);
    this.currentClient=client;
    this.addSectionHeader="Add Section to "+this.currentClient.client_name;
  }

  onSubmit(){
    event.preventDefault();
    this.newSection.client_id=this.currentClient.client_id;
    console.log(this.newSection.section_name, this.newSection.client_id)
    this.addSection();
  }

  onCancel( event: any ){
    event.preventDefault();
    this.dialogRef.close();
  }    

  async loadClient(){
    this.clientService.getClientById( this.clientID ).subscribe(
        ( response: any ) => {
            if( response.ok ){
                this.currentClient = response.body.message;
                this.addSectionHeader="Add Section to "+this.currentClient.client_name;
            }
        },
        ( error: any ) => console.log(error)
    );
  }

  private addSection(): void {
    this.SectionService.createSection(this.newSection).subscribe(
        ( result: any ) => {
            console.log( result );
            if ( result.status === 200 ) {
                this.valid = true;
                this.dialogRef.close();
                this.data.reload();
            }
            else {
              this.valid = false;
            }
        },
        ( error ) => {
            console.error( error );
            this.valid = false;
        }
    );
}

  async getAttributes(){
    const attributes = await this.authService.getAttributes();
    this.clientID = attributes["custom:client_id"];
    this.sectionID = attributes["custom:section_id"];
    this.userRole = attributes["custom:role"];
  }
}