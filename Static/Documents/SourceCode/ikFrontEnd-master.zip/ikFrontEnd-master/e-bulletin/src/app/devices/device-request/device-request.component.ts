import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'device-request',
  templateUrl: './device-request.component.html',
  styleUrls: ['../devices.component.css']
})

export class DeviceRequestComponent implements OnInit {
    
    constructor() { }

    ngOnInit(){}
}