export default interface UserAttribute {

    getValue(): string;
}
