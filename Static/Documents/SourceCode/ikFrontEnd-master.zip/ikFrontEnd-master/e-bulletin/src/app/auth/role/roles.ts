export enum Roles {
  SysAd = "System Administrator",
  CliOwn = "Client Owner",
  SecAd = "Section Administrator",
}
