import UserAttribute from "./UserAttribute";

export default class EmailAttribute implements UserAttribute {
    private email: string;

    constructor( email: string ){
        this.email = email;
    }

    public getValue(): string {
        return this.email;
    }
}
