import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { ClientService } from "./client.service";
import { Observable, BehaviorSubject } from "rxjs";
import { Client } from "./Client";
import { catchError } from 'rxjs/operators';
import { of } from "zen-observable";

export class ClientDataSource implements DataSource<Client> {

    private clientSubject = new BehaviorSubject<Client[]>([]);
    private isLoading = new BehaviorSubject<boolean>(false);

    public loading = this.isLoading.asObservable();
    public clientData = this.clientSubject.asObservable();
    constructor( private clientService: ClientService ){ }

    public connect( collectionViewer: CollectionViewer ): Observable<Client[]> {
        return this.clientSubject.asObservable();
    }

    public disconnect( collectionViewer: CollectionViewer ): void {
        this.clientSubject.complete();
        this.isLoading.complete();
    }

    public loadClients (): void {
        this.isLoading.next(true),
        setTimeout( () =>
            this.clientService.getClients()
                .pipe( 
                    catchError( error => {
                        console.error(error);
                        return of([]);
                    })
                )
                .subscribe( 
                    ( result: any ) => {
                        result.body.message.reverse( ( a,b ) => a.id > b.id);
                        this.clientSubject.next( result.body.message );
                        this.isLoading.next(false)
                    },
                    ( error ) => {
                        if ( error){
                            console.error( error );
                        }
                    }    
                )
            ,3000
        )
    }

}