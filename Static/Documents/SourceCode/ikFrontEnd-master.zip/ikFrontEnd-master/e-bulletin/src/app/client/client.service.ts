import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpResponse} from "@angular/common/http";
import { Client } from './Client';
import { config } from '../config/config';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class ClientService {
    constructor(private http: HttpClient){}

    getClients(): Observable<HttpResponse<Client[]>> {
        return this.http.get<Client[]>(config.api.invokeUrl+'clients/', { observe: 'response' });
    }

    getClientById(clientId: number): Observable<HttpResponse<Client>>{
        return this.http.get<Client>(config.api.invokeUrl+'clients/'+clientId, { observe: 'response' });

    }

    createClient(newClient: Client): Observable<HttpResponse<Client>> {
        return this.http.post<Client>(config.api.invokeUrl+'clients/new', newClient, { observe: 'response' } );
    }

    editClient( client: Client ): Observable<HttpResponse<Client>> {
        return this.http.post<Client>(config.api.invokeUrl+'clients/update', client, { observe: 'response' } );
    }
}
