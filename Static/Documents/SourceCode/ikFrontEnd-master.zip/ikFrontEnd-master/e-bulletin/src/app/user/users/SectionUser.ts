import User from "./User";
import EmailAttribute from "../attributes/EmailAttribute";
import UsernameAttribute from "../attributes/UsernameAttribute";
import {Client} from "../../client/Client";
import {ClientService} from "../../client/client.service";
import {SectionService} from "../../client/section.service";

export default class SectionUser implements User {
    email: EmailAttribute;
    userName: UsernameAttribute;
    isConfirmed:boolean = false;
    clientID: number;
    clientName: string;
    sectionID: number;
    sectionName: string;

    client: Client;
    constructor(private clientService: ClientService, private sectionService: SectionService){
    }


    setClientID( clientID ): void {
        this.clientID = clientID;
        console.log("section "+this.clientID);
        this.loadClient();
    }

    setSectionID( sectionID: number ): void {
        this.sectionID = sectionID;
        this.loadSection();
    }

    private loadClient(): void {
        this.clientService.getClientById(this.clientID).subscribe(
        (response: any) => {

                  this.clientName = response.body.message.client_name? response.body.message.client_name: "" ;
              }
        );
    }

    private loadSection(): void {
        this.sectionService.getSection(this.sectionID).subscribe(
          (response: any) => {

            this.sectionName = response.body.message.section_name? response.body.message.section_name: "" ;
          }
        );
    }

}
