import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {UserListComponent} from "./user-list.component";
import {UserDetailComponent} from "./user-detail.component";
import {UserComponent} from "./user.component";

const userRoutes: Routes = [
    {
        path: 'users',
        component: UserComponent,
        children: [
          {
              path: '',
              component: UserListComponent
          }
        ]
    }

];

@NgModule({
  imports: [
    RouterModule.forRoot(
        userRoutes
    )
  ],
  exports: [
    RouterModule
  ]
})

export class UserRoutingModule { }

