import { Injectable } from '@angular/core';
import { Location } from '@angular/common'
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';

import {AuthService} from "./auth.service";
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  
  constructor(private authService: AuthService, private router: Router, private thislocation:Location ){}
  
  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    var alloweduser = await this.checkAuthentication();
    if (!alloweduser){
      this.router.navigate([''])
      return false;
    } else {
      var allowedpath = await this.checkPath(state.toString());
      if (!allowedpath){
        this.thislocation.back()
        return false;
      } 
    }
    return true;
  }

  async checkAuthentication(){
      const authenticated = await this.authService.isAuthenticated();
      if ( authenticated ){
          return true;
      }
      else{
        return false;
      }
  }

  async checkPath(state){
    var validpath=true;
    var role=await this.authService.getUserRole();
    if ( role == "System-Administrator"){
      if (state.toString().includes('content') || (state.toString().includes('devices') && state.toString().includes('requests'))
      || (state.toString().includes('devices') && state.toString().includes('new'))){
        //return false;
        return true;
      }
    } else if ( role  == "Client-Account-Administrator" || role == "Client-Account-Owner"){
      if (state.toString().includes('client')) {
        return false;
      }
    } else if ( role == "Section-Administrator"){
      if (state.toString().includes('sections') || state.toString().includes('client') || (state.toString().includes('devices') && state.toString().includes('requests'))
      || (state.toString().includes('devices') && state.toString().includes('new'))){
        return false;
      }
    }
    return validpath;
  }

}
