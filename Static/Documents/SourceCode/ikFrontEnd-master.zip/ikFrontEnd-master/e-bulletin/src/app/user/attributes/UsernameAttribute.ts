import UserAttribute from "./UserAttribute";

export default class UsernameAttribute implements UserAttribute {

    username;

    constructor( username: string ){
        this.username = username;
    }

    getValue(): string {
        return this.username;
    }
}
