import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {LoginComponent} from "./login/login.component";
import {AdminRegistrationComponent} from "./admin-registration/admin-registration.component";
import {AccountHolderRegistrationComponent} from "./register/account-holder-registration/account-holder-registration.component";
import {DevicesComponent} from "./devices/devices.component";
import {NewDeviceFormComponent} from "./devices/new-device/new-device-form.component";
import {DeviceDetailComponent} from "./devices/device-detail/device-detail.component";
import { AuthGuard } from './auth/auth.guard';
import { ContentComponent } from './content/content.component';
import {ConfirmSignupComponent} from "./register/confirm-signup.component";
import {ResendVerificationComponent} from "./register/resend-verification.component";

const routes: Routes = [
  // turn this into a child route eventually
  { path: '', redirectTo: 'dashboard', pathMatch: 'full'},
  { path: 'dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'new/user/:email', component: AdminRegistrationComponent },
  { path: 'confirm', component: ConfirmSignupComponent  },
  {  path: 'resend', component: ResendVerificationComponent },
  { path: 'Section-account/new', component: AccountHolderRegistrationComponent }
];

@NgModule({
  imports: [
      RouterModule.forRoot(
          routes,
          {
              enableTracing: true,
              // useHash: true
          }
      )
  ],
  exports: [
      RouterModule
  ]
})

export class AppRoutingModule { }
