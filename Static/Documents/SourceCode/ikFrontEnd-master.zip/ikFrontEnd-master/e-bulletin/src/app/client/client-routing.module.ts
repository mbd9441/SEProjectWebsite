import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {ClientComponent} from "./client/client.component";
import {SectionComponent} from "./section/section.component";
import {ClientListComponent} from "./client-list/client-list.component";
import {NewClientFormComponent} from "./new-client/new-client.component";
import {SectionListComponent} from "./section-list/section-list.component";
import {AuthGuard} from "../auth/auth.guard";
import { ClientDetailComponent } from './client-detail/client-detail.component';



const clientRoutes: Routes = [
  {
    path: 'client',
    component: ClientComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: '',
        component: ClientListComponent,
        // canActivate: [AuthGuard],
      },
      {
        path: 'new',
        // canActivate: [SysAdminGuard],
        component: NewClientFormComponent
      },
      {
          path: ':id/details',
          component: ClientDetailComponent
      },
      {
        path: ':id',
        component: SectionComponent,
        children: [
          {
            path: 'sections',
            component: SectionListComponent
          },

        ]
      }
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      clientRoutes,
      {
        enableTracing: true
      }
    )
  ],
  exports: [
    RouterModule
  ]
})

export class ClientRoutingModule { }

