import {Component, OnInit, Inject} from "@angular/core";
import { ClientService } from "../client.service";
import { Client } from "../Client";
import { AuthService } from "src/app/auth/auth.service";
import { Router } from "@angular/router";
import { ClientListComponent } from "../client-list/client-list.component";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'new-client',
  templateUrl: './new-client.component.html',
  styleUrls: ['../client.css']
})

export class NewClientFormComponent implements OnInit {
  client: Client;
  valid: boolean = true;

  constructor(private clientService: ClientService, private authService: AuthService, private router: Router,
    public dialogRef: MatDialogRef<ClientListComponent>, @Inject(MAT_DIALOG_DATA) public data: any){
        this.client = new Client();
        this.addClient = this.addClient.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
  }

  private addClient(): void {
    
    this.clientService.createClient(this.client).subscribe(
        ( result: any ) => {
            console.log( result );
            if ( result.status === 200 ) {
                this.valid = true;
                this.dialogRef.close();
                this.data.reload();
            }
            else {
              this.valid = false;
            }
        },
        ( error ) => {
            console.error( error );
            this.valid = false;
        }
    );
}

  onSubmit(event){
      event.preventDefault();
      this.addClient();
  }

  onCancel( event: any ){
    event.preventDefault();
    this.dialogRef.close();
}

  ngOnInit(){}


}
