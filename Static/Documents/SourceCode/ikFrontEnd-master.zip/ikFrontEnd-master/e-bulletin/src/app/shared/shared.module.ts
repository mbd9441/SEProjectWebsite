import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { 
  MatTableModule, 
  MatProgressSpinnerModule, 
  MatCheckboxModule, 
  MatIconModule, 
  MatMenuModule, 
  MatButtonModule, 
  MatDialogModule, 
  MatFormFieldModule,
  MatInputModule,
  MatSidenavModule,
  MatSnackBarModule,
  MatGridListModule,
  MatCardModule,
  MatOptionModule,
  MatSelectModule} from '@angular/material'; 
import { NavbarModule } from '../navbar/navbar.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';


@NgModule({
 imports:      [ 
   CommonModule,
   MatTableModule,
   MatProgressSpinnerModule,
   FlexLayoutModule,
   MatCheckboxModule,
   MatIconModule,
   MatMenuModule,
   MatButtonModule,
   MatDialogModule,
   MatFormFieldModule,
   MatInputModule,
   NavbarModule,
   MatSidenavModule,
   MatSnackBarModule,
   BrowserAnimationsModule,
   MatGridListModule,
   MatCardModule,
   MatOptionModule,
   MatSelectModule,
  ],
 declarations: [  

 ],
exports:[ 
  CommonModule, 
  FormsModule 
  ]
})
export class SharedModule { }
