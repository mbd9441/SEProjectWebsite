import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AppRoutingModule } from './app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminRegistrationComponent } from './admin-registration/admin-registration.component';
import {AccountHolderRegistrationComponent} from "./register/account-holder-registration/account-holder-registration.component";
import {ContentModule} from "./content/content.module";
import { ClientModule } from './client/client.module';
import { DevicesModule } from './devices/devices.module';
import {HttpClientModule} from "@angular/common/http";
import {FormsModule} from "@angular/forms";

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NavbarModule } from './navbar/navbar.module';

import {
  MatTableModule,
  MatProgressSpinnerModule,
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatCardModule} from '@angular/material';
import {UserModule} from "./user/user.module";
import {ConfirmSignupComponent} from "./register/confirm-signup.component";
import {ResendVerificationComponent} from "./register/resend-verification.component";

@NgModule({
  declarations: [
      AppComponent,
      LoginComponent,
      RegisterComponent,
      DashboardComponent,
      AdminRegistrationComponent,
      AccountHolderRegistrationComponent,
      ConfirmSignupComponent,
      ResendVerificationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    FlexLayoutModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatInputModule,
    AppRoutingModule,
    ContentModule,
    ClientModule,
    DevicesModule,
    NavbarModule,
    UserModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
