import {Component, OnInit} from "@angular/core";
import { ClientService } from "../client.service";
import { Client } from "../Client";
import { ClientDataSource } from "../client.data-source";
import { SelectionModel } from "@angular/cdk/collections";
import { NewClientFormComponent } from "../new-client/new-client.component";
import { MatDialog } from "@angular/material";
import { ClientDetailComponent } from "../client-detail/client-detail.component";

@Component({
  selector: 'client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['../client.css']
})

export class ClientListComponent implements OnInit{

    dataSource: ClientDataSource;
    tableColumns: string[] = [];
    selection = new SelectionModel<Client>(true, []);
    client: Client[] = [];

    constructor(public modal: MatDialog, private clientService: ClientService){
        this.tableColumns = ["select","id", "name", "details"];
        this.dataSource = new ClientDataSource( this.clientService );
        this.dataSource.clientData.subscribe( (client: Client[]) => this.client = client  );
    }


    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected(): boolean {
        const numSelected = this.selection.selected.length;
        const numRows = this.client.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle(): void {
        this.isAllSelected() ?
            this.selection.clear() :
            this.client.forEach(row => this.selection.select(row));
    }

    ngOnInit(){
        
        this.dataSource.loadClients();
        
    }

    openModal(): void {
        this.modal.open(NewClientFormComponent, {
            width: '50%',
            data: { reload: (  ) => this.onReload() }
        });
    }

    openDetailModal(client: Client): void {
        this.modal.open(ClientDetailComponent, {
            width: '50%',
            data: { reload: (  ) => this.onReload(), client }
        });
    }

    onReload( silent:boolean = false ): void {
        this.dataSource.loadClients();
    }

}
