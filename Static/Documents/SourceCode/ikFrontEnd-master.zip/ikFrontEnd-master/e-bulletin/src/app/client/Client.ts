export class Client implements Client {
  client_id?: number;
  client_name: string;
  
  constructor(client_id = null, client_name = null){
      this.client_id = client_id;
      this.client_name = client_name;
  }
}