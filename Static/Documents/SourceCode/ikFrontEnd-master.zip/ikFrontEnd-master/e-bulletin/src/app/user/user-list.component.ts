import { Component, OnInit } from '@angular/core';
import { UserTypes } from "./users/User";
import {AuthService} from "../auth/auth.service";
import {authDecorator} from "aws-amplify-angular/dist/src/providers/auth.decorator";


@Component({
    selector: 'user-list',
    templateUrl: './user-list.component.html',
    styleUrls: ['./user.component.css']
})
export class UserListComponent implements OnInit {

    types: string[] = Object.values(UserTypes);
    labels: string[] = [];
    PRIMARY = "primary";
    ACCENT = "accent";
    color = this.PRIMARY;
    backgroundColor = this.ACCENT;
    constructor(private authService: AuthService) {
        this.chooseLabels();
    }

    async chooseLabels(){
        const role = await this.authService.getUserRole();

        switch ( role ) {
            case UserTypes.CLI_ACC_OWNER:
            case  UserTypes.CLI_ACC_ADMIN:
                this.types = this.types.filter( type => type !== UserTypes.SYS_ADMIN );
                break;

            case UserTypes.SEC_ADMIN:
                this.types = this.types.filter( type =>
                    ( (type !== UserTypes.SYS_ADMIN) && (type != UserTypes.CLI_ACC_OWNER)
                      &&  type != UserTypes.CLI_ACC_ADMIN )
                );
                break;
            default:
                break;
        }

        this.labels = this.types.map( (type) => type.replace( /\-/g, ' ' ) + 's');

    }

    ngOnInit() {
    }


}
