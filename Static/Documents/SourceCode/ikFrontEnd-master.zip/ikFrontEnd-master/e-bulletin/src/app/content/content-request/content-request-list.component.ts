import { Component, OnInit } from '@angular/core';
import { Content } from '../Content';
import { ContentService } from '../content.service'
import { HttpClient } from '@angular/common/http';
import { ContentDataSource } from "../content.data-source";
import { AuthService } from "src/app/auth/auth.service";

@Component({
  selector: 'content-request-list',
  templateUrl: './content-request-list.component.html',
  styleUrls: ['content-request.component.css']
})

export class ContentRequestListComponent implements OnInit {
    content: Content[] = []
    dataSource: ContentDataSource;
    userRole: string = '';
    clientID: number;
    sectionID: number;

    constructor(private contentService: ContentService, private http: HttpClient, private authService:AuthService) {
        this.dataSource = new ContentDataSource( this.contentService );
        this.dataSource.contentData.subscribe( (content: Content[]) => this.content = content  );
    }

    ngOnInit() {
        this.loadContentRequests();
    }

    onReload( silent:boolean = false ): void {
        this.loadContentRequests();
    }

    async loadContentRequests(){
        await this.getAttributes();
        if (this.sectionID){
            this.dataSource.loadContentRequestsBySection(this.sectionID);
            console.log("section")
        } else {
            if (this.clientID){
                this.dataSource.loadContentRequestsByClient(this.clientID);
                console.log("client" + this.clientID)
            } else {
                this.dataSource.loadContentRequests();
            }
        }
    }



    async getAttributes(){
        const attributes = await this.authService.getAttributes();
        this.clientID = attributes["custom:client_id"];
        this.sectionID = attributes["custom:section_id"];
        this.userRole = attributes["custom:role"];
    }
}
