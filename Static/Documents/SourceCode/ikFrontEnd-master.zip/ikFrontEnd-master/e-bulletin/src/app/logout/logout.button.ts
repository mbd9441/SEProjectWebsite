import {Component, OnInit} from "@angular/core";
import {AuthService} from "../auth/auth.service";

@Component({
  selector: 'logout-button',
  templateUrl: './logout.button.html',
  styleUrls: ['../login/login.component.css']
})

export class LogoutButton implements OnInit {

  constructor(private authService:AuthService) {

  }

  onClick(e: Event){
      event.preventDefault();
      this.authService.logout();
  }

  ngOnInit(){

  }
}
