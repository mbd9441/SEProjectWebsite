import {Component, Input, OnInit, Inject} from '@angular/core';
import {Client} from "../Client";
import { ClientService } from '../client.service';
import { ActivatedRoute } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ClientListComponent } from '../client-list/client-list.component';
import { MatInputModule } from '@angular/material'

@Component({
  selector: 'client-detail',
  templateUrl: './client-detail.component.html',
  styleUrls: ['../client/client.component.css']
})

export class ClientDetailComponent implements OnInit {
    @Input()
    client: Client;
    editable: boolean;
    loading: boolean;
    currName: string = "";

    constructor(private clientService: ClientService, private route: ActivatedRoute,
        public dialogRef: MatDialogRef<ClientListComponent>, @Inject(MAT_DIALOG_DATA) public data: any ) { 
        this.editable = false;
        this.client = new Client();
    }

  ngOnInit() {
    this.client = this.data.client;
    this.currName=this.client.client_name;
  }

  toggleEditable( event ){
      event.preventDefault();
      this.currName=this.client.client_name;
      this.editable = !this.editable;
  }

  onCancel( event: any ){
    event.preventDefault();
    this.dialogRef.close();
  }


  editClient( event ): void {
      const editedClient = {client_name: this.currName, client_id:this.client.client_id };
      if (this.currName === this.client.client_name){
          this.toggleEditable(event);
      }
      else {

          this.clientService.editClient( editedClient ).subscribe( 
              ( result: any )  => {
                  if ( result.ok ){
                      this.client.client_name = this.currName;
                      this.toggleEditable( event );
                  }
                  else {
                      this.currName = this.client.client_name;
                  }
              },
              ( error: any ) => {
                  this.currName = this.client.client_name;
                  console.log(error);
              }
          );
    }
  }

}
