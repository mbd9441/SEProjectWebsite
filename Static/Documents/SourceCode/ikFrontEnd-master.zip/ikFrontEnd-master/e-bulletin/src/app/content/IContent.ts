export interface IContent {

    content_id?: number
    title: string
    description: string
    content?: string
    status: string
    submitter: string
    client_id: number
    device_id?: number


}