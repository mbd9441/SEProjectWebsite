import { NgModule } from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {DevicesComponent} from "./devices.component";
import {NewDeviceFormComponent} from "./new-device/new-device-form.component";
import {DeviceListComponent} from "./device-list/device-list.component";
import {ContentComponent} from "../content/content.component";
import {NewContentFormComponent} from "../content/new-content/new-content.component";
import {ContentListComponent} from "../content/content-list/content-list.component";
import {AuthGuard} from "../auth/auth.guard";
import {SysAdminGuard} from "../auth/role/sysAdmin.guard";
import {ClientGuard} from "../auth/role/client.guard";
import { DeviceRequestComponent } from './device-request/device-request.component';
import { ApprovalFormComponent } from './device-request/approval-form.component';
import { DeviceRequestListComponent } from './device-request/device-request-list.component';
import { DeviceDetailComponent } from './device-detail/device-detail.component';
import { DeviceContentListComponent } from './device-content-list/device-content-list.component';

const deviceRoutes: Routes = [
    {
        path: 'devices',
        component: DevicesComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: '',
                component: DeviceListComponent
            },
            {
                path: ':id/details',
                component: DeviceDetailComponent
            },
            {
                path: ':id/contents',
                component: DeviceContentListComponent
            },
            {
                path: 'requests',
                component: DeviceRequestComponent,
                canActivate: [AuthGuard],
                children: [
                    {
                        path: '',
                        component: DeviceRequestListComponent
                    },
                    {
                        path: 'approve/:id',
                        component: ApprovalFormComponent
                    }
                ]
            },
            {
                path: 'new',
                canActivate: [AuthGuard],
                component: NewDeviceFormComponent
            },
            {
                path: 'show/:id/content',
                component: ContentComponent,
                children: [
                  {
                      path: '',
                      component: ContentListComponent
                  },
                  {
                      path: 'new',
                      component: NewContentFormComponent

                  }
                ]

            }
        ]
    }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      deviceRoutes,
      {
        enableTracing: true
      }
    )
  ],
  exports: [
    RouterModule
  ]
})

export class DevicesRoutingModule { }

