import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpResponse} from "@angular/common/http";
import { Section } from './Section';
import { config } from '../config/config';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class SectionService {

    constructor(public http: HttpClient){}

    getSections(): Observable<HttpResponse<Section[]>> {
        return this.http.get<Section[]>(config.api.invokeUrl+'sections/', { observe: 'response' } );
    }

    getSection( sectionID: number ): Observable<HttpResponse<Section>> {
        return this.http.get<Section>( config.api.invokeUrl + `sections/${sectionID}`, { observe: 'response' } );
    }

    createSection(newSection: Section): Observable<HttpResponse<Section>> {
        return this.http.post<Section>(config.api.invokeUrl+'sections/new', newSection, { observe: 'response' } );
    }

    findByClientId(clientID: number): Observable<HttpResponse<Section[]>> {
        return this.http.get<Section[]>(config.api.invokeUrl+`sections/find_by_client/${clientID}`, { observe: 'response' } )
    }
}
