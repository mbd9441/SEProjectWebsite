import { Injectable } from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute} from '@angular/router';
import {AuthGuard} from "../auth.guard";
import {Account} from "../../Account";
import {Roles} from "./roles";

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  public constructor(private authGuard: AuthGuard, private router: Router, private route: ActivatedRoute){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Promise<boolean>  {
        return this.authGuard.canActivate(next, state).then((authenticated) => {
            if (!authenticated){
                return Promise.resolve(false);
            }
            else {

                const user:Account = JSON.parse(localStorage.getItem('currUser'));
                console.log("YERR in here "+next.url[0].toString());
                switch (next.url[0].toString()) {

                    case 'client':


                        return Promise.resolve(user.role !== Roles.SecAd);
                    case 'section':
                    default:
                        return Promise.resolve(true);
               }
            }
        });
  }
}
