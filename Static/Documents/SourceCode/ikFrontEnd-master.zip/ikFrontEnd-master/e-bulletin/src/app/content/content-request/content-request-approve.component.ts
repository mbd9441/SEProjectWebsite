import { Component, OnInit, Input } from '@angular/core';
import { Content } from '../Content'
import { ContentService } from '../content.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { MatSnackBar } from '@angular/material';
import { ContentRequestListComponent } from './content-request-list.component';

@Component({
  selector: 'content-request-approve',
  templateUrl: './content-request-approve.component.html',
  styleUrls: ['./content-request.component.css']
})
export class ContentRequestApproveComponent implements OnInit {
  @Input() content: Content;
  valid: boolean;
  constructor(private contentService: ContentService, private router: Router, private location: Location, private snackbar: MatSnackBar, private requestList:ContentRequestListComponent) { }

  ngOnInit() {
  }

  openSnackBar(message) {
    this.snackbar.open(message, 'OK', {duration: 3000})
  };

  approveContent(event) {
    console.log(this.content.content_id)
    this.contentService.approveContent(this.content.content_id).subscribe(
      ( result: any ) => {
          console.log(result);
          if ( result.status === 200 ) {
            this.valid = true;
            
            this.requestList.onReload();
            this.openSnackBar("Content Approved");
          }
          else {
            this.valid = false;
            this.openSnackBar(result);
          }
      },
      ( error ) => {
          console.error( error );
          this.valid = false;
      }
    );
  }

}
