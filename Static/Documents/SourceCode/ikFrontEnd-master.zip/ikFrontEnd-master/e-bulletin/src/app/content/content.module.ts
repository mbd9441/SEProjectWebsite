import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentRoutingModule } from "./content-routing.module";
import { ContentComponent } from "./content.component";
import { ContentListComponent } from "./content-list/content-list.component";
import {ContentDetailComponent} from "./content-detail/content-detail.component";
import {NewContentFormComponent} from "./new-content/new-content.component";
import {PushFormComponent} from "./content-actions/push-form.component";
import {ArchiveComponent} from "./content-actions/archive.component";
import {PushComponent} from "./content-actions/push.component";
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { 
  MatTableModule, 
  MatProgressSpinnerModule, 
  MatCheckboxModule, 
  MatIconModule, 
  MatMenuModule, 
  MatButtonModule, 
  MatDialogModule, 
  MatFormFieldModule,
  MatInputModule,
  MatSidenavModule,
  MatListModule,
  MatSnackBarModule,
  MatGridListModule,
  MatCardModule,
  MatOptionModule,
  MatSelectModule} from '@angular/material';
import { NavbarModule } from '../navbar/navbar.module';
import {LogoutModule} from "../logout/logout.module";
import { ContentRequestFormComponent } from './content-request/content-request-form.component';
import { ContentRequestListComponent } from './content-request/content-request-list.component';
import { ContentRequestDetailComponent } from './content-request/content-request-detail.component';
import { ContentRequestApproveComponent } from './content-request/content-request-approve.component';
import { ContentRequestDenyComponent } from './content-request/content-request-deny.component';
import { ContentRequestSuccessComponent } from './content-request/content-request-success.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ContentRequestComponent } from './content-request/content-request.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    ContentRoutingModule,
    LogoutModule,
    FormsModule,
    MatTableModule,
    MatProgressSpinnerModule,
    FlexLayoutModule,
    MatCheckboxModule,
    MatIconModule,
    MatMenuModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    NavbarModule,
    MatSidenavModule,
    MatSnackBarModule,
    BrowserAnimationsModule,
    MatGridListModule,
    MatCardModule,
    MatOptionModule,
    MatSelectModule,
    SharedModule
  ],
  declarations: [
    ContentComponent,
    ContentListComponent,
    NewContentFormComponent,
    PushComponent,
    PushFormComponent,
    ArchiveComponent,
    PushComponent,
    ContentRequestComponent,
    ContentRequestSuccessComponent,
    ContentRequestListComponent,
    ContentRequestDetailComponent,
    ContentRequestApproveComponent,
    ContentRequestDenyComponent,
    ContentRequestFormComponent,
    ContentDetailComponent
  ],
  exports: [
    ContentRequestDetailComponent,
    ContentRequestApproveComponent,
    ContentRequestDenyComponent
]

})
export class ContentModule { }
