export class DeviceApproval {
    
    name: string
    client_id: number;
    section_id: number;
    instance_id: string;

}