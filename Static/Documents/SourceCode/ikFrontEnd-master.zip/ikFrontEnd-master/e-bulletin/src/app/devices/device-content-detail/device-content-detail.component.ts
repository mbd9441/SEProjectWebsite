import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { IContent } from 'src/app/content/IContent';
import { Content } from 'src/app/content/Content';
import {DeviceContent} from "../../content/device-content";


@Component({
  selector: 'app-device-content-detail',
  templateUrl: './device-content-detail.component.html',
  styleUrls: ['../devices.component.css']
})
export class DeviceContentDetailComponent implements OnInit {
  @Input()
  content: IContent = new Content();
  @Input()
  deviceContent: DeviceContent = new DeviceContent();

  @Output()
  updateDeviceStatus: EventEmitter<DeviceContent>;
  constructor(  ){
    this.updateDeviceStatus = new EventEmitter();
  }

  ngOnInit(){
  }

  onChange(event: any){

      this.deviceContent.is_active = event.checked;
      this.updateDeviceStatus.emit(this.deviceContent);
  }


}
