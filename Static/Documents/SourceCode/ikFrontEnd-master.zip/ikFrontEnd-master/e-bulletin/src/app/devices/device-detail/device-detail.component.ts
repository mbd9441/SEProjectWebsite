import { Component, OnInit, Input } from '@angular/core';
import { Device } from '../Device';
import { DeviceService } from '../device.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'device-detail',
  templateUrl: './device-detail.component.html',
  styleUrls: ['../devices.component.css']
})

export class DeviceDetailComponent implements OnInit {
  @Input()
  device: Device = new Device();
  
  deviceID: number;
  constructor( private deviceService: DeviceService, private route: ActivatedRoute ){

  }

  ngOnInit(){
      console.log(this.route.params);
      this.deviceID = +this.route.params.subscribe( params => { 
          console.log(params);
          this.deviceID = +params['id'];
          this.loadDevice();
        });

      
  }

  private loadDevice(  ){
      console.log(this.deviceID);
      this.deviceService.getDevice( this.deviceID ).subscribe(
          ( response: any ) => this.device = response.body.message,
          ( error ) => console.error( error )
      )
  }
}
