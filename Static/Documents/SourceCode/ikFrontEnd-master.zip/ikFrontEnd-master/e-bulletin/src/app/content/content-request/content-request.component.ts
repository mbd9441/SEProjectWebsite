import { OnInit, Component } from "@angular/core";

@Component({
    selector: 'content-request',
    templateUrl: './content-request.component.html',
    styleUrls: ['../content.component.css']
  })

export class ContentRequestComponent implements OnInit {

    constructor(){}

    ngOnInit(){
    }
}
