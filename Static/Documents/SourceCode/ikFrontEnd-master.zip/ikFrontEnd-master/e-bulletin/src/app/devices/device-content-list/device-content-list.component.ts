import { Component, OnInit, Input } from '@angular/core';
import { ContentService } from 'src/app/content/content.service';
import {HttpClient} from "@angular/common/http";
import { ActivatedRoute } from '@angular/router';
import { Device } from '../Device';
import { DeviceService } from '../device.service';
import {Location} from '@angular/common';
import {DeviceContentData, DeviceContentDataSource} from "../device-content.data-source";
import {DeviceContent} from "../../content/device-content";

@Component({
  selector: 'app-device-content-list',
  templateUrl: './device-content-list.component.html',
  styleUrls: ['../devices.component.css']
})
export class DeviceContentListComponent implements OnInit {
    @Input()
    deviceID: number;
    device: Device = new Device();
    deviceContentData: DeviceContentData[] = [];
    dataSource: DeviceContentDataSource;

    constructor(private contentService: ContentService, private http: HttpClient, private route: ActivatedRoute, private deviceService: DeviceService, private _location: Location) {
        this.dataSource = new DeviceContentDataSource( this.contentService );
        this.dataSource.deviceContentData.subscribe(
          (deviceContentData: DeviceContentData[]) => {
              this.deviceContentData = deviceContentData;
        });
    }

    ngOnInit() {
      this.route.params.subscribe( params => {
          this.deviceID = +params['id'];
          this.dataSource.loadDeviceContents(this.deviceID);
          this.loadDevice();
      });
    }

    reload(  ): void {
        console.log( this.deviceID );
        this.dataSource.loadDeviceContents(this.deviceID, true);
    }

    private loadDevice(  ){
      this.deviceService.getDevice( this.deviceID ).subscribe(
          ( response: any ) => this.device = response.body.message,
          ( error ) => console.error( error )
      )
    }

  updateDeviceStatus(deviceContent: DeviceContent){
      console.log("yerr");
      const topic_name: string = this.device.topic_name;

      this.dataSource.updateDeviceStatus( {topic_name:topic_name, ...deviceContent} );
      this.reload();
  }

  backClicked() {
    this._location.back();
  }
}
