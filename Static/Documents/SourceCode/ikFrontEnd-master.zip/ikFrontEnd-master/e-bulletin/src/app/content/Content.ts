export class Content implements Content{
    content_id: number;
    title!: string ;
    description: string ;
    status: string ;
    submitter!: string ;
    content!: string ;
    client_id: number;
    section_id: number;
    device_id: number ;

    
    constructor(content_id = null, title = null, description= null, content= null, status= null, submitter= null, client_id= null, section_id=null, device_id=null){
        this.content_id = content_id;
        this.title = title;
        this.description = description;
        this.status = status;
        this.submitter = submitter;
        this.content = content;
        this.client_id = client_id;
        this.section_id = section_id;
        this.device_id=device_id;
    }

    
}
