import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'new-device',
  templateUrl: './new-device.component.html',
  styleUrls: ['../devices.component.css']
})

export class NewDeviceFormComponent implements OnInit {

  name: string = "Name of this Device";
  client: string = "RIT";

  onSubmit(){
    alert("Submitted a new device");
  }
  constructor() { }

  ngOnInit() { }

}
