import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpResponse} from "@angular/common/http";
import { Content } from './Content';
import { DeviceContent } from './device-content';
import { config } from '../config/config';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class ContentService {
    postHeaders: HttpHeaders;
    constructor(private http: HttpClient){}

    getContents(): Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/', { observe: 'response' });
    }

    getContentsByClient( id: number ): Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/client/'+id, { observe: 'response' });
    }

    getContentsBySection( id: number ): Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/section/'+id, { observe: 'response' });
    }

    getContentsByDevice( id: number ): Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'devices/deployed/'+id, { observe: 'response' });
    }

    getContent( id: number ): Observable<HttpResponse<Content>> {
        return this.http.get<Content>( config.api.invokeUrl+'contents/'+id, {observe: 'response'} );
    }

    createContent(newContent: Content): Observable<HttpResponse<Content>> {
        return this.http.post<Content>(config.api.invokeUrl+'contents/new', newContent, { observe: 'response' } );
    }

    pushContent(pushedContent: any): Observable<HttpResponse<DeviceContent>> {
        return this.http.post<any>(config.api.invokeUrl+'devices/content/push', pushedContent, { observe: 'response' } );
    }

    updateDeviceContentStatus( deviceContent: any ): Observable<HttpResponse<DeviceContent>> {
      return this.http.post<DeviceContent>(  config.api.invokeUrl+'devices/content/update', deviceContent, {observe: 'response'} );
    }

    requestContent( contentRequest: Content ): Observable<HttpResponse<string>> {
        return this.http.post<string>(config.api.invokeUrl+'contents/request', contentRequest, {observe: 'response'});
    }

    getPendingContent():  Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/pending', { observe: 'response' } );
    }

    getPendingContentByClient( id: number ):  Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/pending/client/'+id, { observe: 'response' } );
    }

    getPendingContentBySection( id: number ):  Observable<HttpResponse<Content[]>> {
        return this.http.get<Content[]>(config.api.invokeUrl+'contents/pending/section/'+id, { observe: 'response' } );
    }

    approveContent( ContentID: number ): Observable<HttpResponse<Content>> {
        return this.http.post<null>(config.api.invokeUrl+'contents/approve/'+ContentID, null, {observe: 'response'});
    }

    denyContent( ContentID: number ): Observable<HttpResponse<Content>> {
        return this.http.post<null>(config.api.invokeUrl+('contents/deny/'+ContentID), null, {observe: 'response'});
    }


}
