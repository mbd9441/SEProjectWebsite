import {Component, OnInit, Input} from "@angular/core";
import { IContent } from "../IContent";
import { Content } from "../Content";
import { ContentService } from "../content.service";
import { Router, ActivatedRoute } from "@angular/router";
@Component({
  selector: 'content-detail',
  templateUrl: './content-detail.component.html',
  styleUrls: ['../content.component.css']
})

export class ContentDetailComponent implements OnInit {
  @Input()
  content: IContent = new Content();
  
  contentID: number;
  constructor( private contentService: ContentService, private route: ActivatedRoute ){

  }

  ngOnInit(){
      console.log(this.route.params);
      this.contentID = +this.route.params.subscribe( params => { 
          console.log(params);
          this.contentID = +params['id'];
          this.loadContent();
        });

      
  }

  private loadContent(  ){
      console.log(this.contentID);
      this.contentService.getContent( this.contentID ).subscribe(
          ( response: any ) => this.content = response.body.message,
          ( error ) => console.error( error )
      )
  }


}
