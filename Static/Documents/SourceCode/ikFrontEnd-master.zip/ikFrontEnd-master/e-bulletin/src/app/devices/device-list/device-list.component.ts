import { Component, OnInit } from '@angular/core';
import { DeviceService } from '../device.service';
import { Device } from '../Device';
import { AuthService } from 'src/app/auth/auth.service';
import {DeviceDataSource } from '../device.data-source'
import { SelectionModel } from "@angular/cdk/collections";

@Component({
  selector: 'device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['../devices.component.css']
})

export class DeviceListComponent implements OnInit {
    dataSource: DeviceDataSource;
    tableColumns: string[] = [];
    selection = new SelectionModel<Device>(true, []);
    devices: Device[] = [];
    userRole='';
    clientID: number;
    sectionID: number;
    constructor(private deviceService: DeviceService, private authService:AuthService){
        this.tableColumns = ["select","name", "id", "section", "detail"];
        this.dataSource = new DeviceDataSource( this.deviceService, this.authService );
        this.dataSource.deviceData.subscribe( (devices: Device[]) => this.devices = devices  );
    }

    ngOnInit() {
        this.dataSource.loadDevicesByRole();
    }

    async getUserRole(){
        const role= await this.authService.getUserRole();
        this.userRole=role;
      }

      /** Whether the number of selected elements matches the total number of rows. */
      isAllSelected(): boolean {
          const numSelected = this.selection.selected.length;
          const numRows = this.devices.length;
          return numSelected === numRows;
      }

      /** Selects all rows if they are not all selected; otherwise clear selection. */
      masterToggle(): void {
          this.isAllSelected() ?
              this.selection.clear() :
              this.devices.forEach(row => this.selection.select(row));
      }

      onReload( silent:boolean = false ): void {
          this.dataSource.loadDevices();
      }


}
