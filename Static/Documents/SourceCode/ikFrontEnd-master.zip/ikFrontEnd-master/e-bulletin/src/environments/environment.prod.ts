export const environment = {
  production: true
};

export const server = "https://6dxyr3ciy3.execute-api.us-east-1.amazonaws.com/dev";
