# ikBackEnd

Now deploying automatically via AWS CodePipeline

# Travis URL:
https://travis-ci.com/rit2018-SeniorProject/ikBackEnd.svg?token=nfrDSvwKPtYQvNJjPhzo&branch=master
