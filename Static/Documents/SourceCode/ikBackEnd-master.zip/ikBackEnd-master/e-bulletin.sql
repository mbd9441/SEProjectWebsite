/**
    SQL script to create the E_bulletin database
    and all accompanying tables.

    Author - Philip Bedward
    Date - 11/13/18
**/
CREATE DATABASE IF NOT EXISTS E_Bulletin;
USE E_Bulletin;

CREATE TABLE IF NOT EXISTS Account(
    account_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_digest CHAR(64) NOT NULL,
    role ENUM("System Administrator", "Client Owner", "Section Administrator") NOT NULL
);

CREATE TABLE IF NOT EXISTS Client(
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Section (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_name VARCHAR(50) NOT NULL,
    client_id INT NOT NULL,
    FOREIGN KEY(client_id) 
    REFERENCES client(client_id)
    ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS Content(
    content_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL,
    content VARCHAR(255),
    status ENUM('Active','Archived','Pending','Reserved','Expired','Approved') NOT NULL,
    submitter VARCHAR(255) NOT NULL,
    client_id INT NOT NULL,
    FOREIGN KEY(client_id)
    REFERENCES client(client_id)
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Device (
    device_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    topic_name VARCHAR(255),
    section_id INT NOT NULL,
    FOREIGN KEY(section_id) 
    REFERENCES Section(section_id)
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS Device_Content(
    content_id INT NOT NULL,
    device_id INT NOT NULL,
    time_published DATETIME,
    is_active BOOLEAN NOT NULL,
    is_saved BOOLEAN NOT NULL,

    PRIMARY KEY(content_id,device_id),
    
    FOREIGN KEY(content_id) 
    REFERENCES Content(content_id)
    ON UPDATE CASCADE,
    
    FOREIGN KEY(device_id) 
    REFERENCES Device(device_id)
    ON UPDATE CASCADE
);
