"""Handler for all section related lambda requests"""
import sys
import logging
import pymysql
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def connection():
    """
    Establishes a connection to mysql in the AWS RDS instance.
    :return: conn -  a mysql connection to the RDS instance
    """
    rds_host = "rdsdbinstance.cy9qzat2q72f.us-east-1.rds.amazonaws.com"
    name = "Admin"
    password = "password"
    db_name = "E_Bulletin"

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, cursorclass=pymysql.cursors.DictCursor)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn


def all(event, context):
    """
    Fetches a query of all sections in the Section database table.
    :param event: The Lambda event.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    logger.info("Fetching list of all sections")
    cur = conn.cursor()
    cur.execute("SELECT * from Section")
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def get( event, context ):
    conn = connection()
    params = event['pathParameters']
    sectionID = params.get('section_id')
    logger.info("Fetching one section %s" , sectionID )
    error = False
    statusCode = 200
    message = ""

    if sectionID is None:
        logger.error("The section ID was not included in request parameters")
        message = "Could not find the Section"
        statusCode = 404
        error = True
        conn.close()

    elif not error:
        try:
            sql = "SELECT * from Section WHERE section_id = %s"
            cursor = conn.cursor()
            cursor.execute( sql, sectionID )
            conn.commit()
            message = cursor.fetchone()
            logger.info("Query results: %s", message)
        except:
            logger.error("Failed to retrieve the section by section id")
            statusCode = 400
            message = "Sorry an error has occured while trying to retrieve the sections"
    body = {
        "message": message
    }
    return {
        'statusCode': statusCode,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def post(event, context):
    """
    Inserts a new section into the Section database table.
    :param event: The Lambda event containing a section name and client id to be inserted.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    cur = conn.cursor()
    
    try:
        sql = "INSERT INTO `Section` (`section_name`, `client_id`) VALUES (%s, %s)"
        cur.execute(sql, (obj['section_name'], obj['client_id']))
        conn.commit()
    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    body = {
        "message": "Added new entry to table"
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def findByClientId( event, context ):
    logger.info("Fetching a list of sections filtered by client id")
    conn = connection()
    params = event['pathParameters']
    clientID = params.get('client_id')
    error = False
    statusCode = 200
    message = ""

    if clientID == None:
        logger.error("The client ID was not included in request parameters")
        message = "Could not find the Section"
        statusCode = 404
        error = True
        conn.close()

    elif not error:
        try: 
            sql = "SELECT * FROM Section WHERE client_id = %s"
            cursor = conn.cursor()
            cursor.execute( sql, clientID )
            conn.commit()
            message = cursor.fetchall()
            logger.info("Query results: {}".format(message))
            
        except: 
            logger.error("Failed to retrieve the list of sections by client id")
            statusCode = 400
            message = "Sorry an error has occured while trying to retrieve the sections"
        
        finally:
            conn.close()
    
    body = {
        "message": message
    }

    return {
        'statusCode': statusCode,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
