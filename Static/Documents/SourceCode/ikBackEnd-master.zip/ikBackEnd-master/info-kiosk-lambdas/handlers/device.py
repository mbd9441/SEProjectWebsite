import sys
import logging
import pymysql
import json
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def connection():
    """
    Establishes a connection to mysql in the AWS RDS instance.
    :return: conn -  a mysql connection to the RDS instance
    """
    rds_host = "rdsdbinstance.cy9qzat2q72f.us-east-1.rds.amazonaws.com"
    name = "Admin"
    password = "password"
    db_name = "E_Bulletin"

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, cursorclass=pymysql.cursors.DictCursor)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn

def all(event, context):
    logger.info("Fetching a list of all devicez")
    status_code = 200
    try:
        conn = connection()
        cursor = conn.cursor()
        sql = "SELECT * FROM `Device`"
        cursor.execute(sql)
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results: {}".format(message))
    except:
        logger.error("Query for all devices failed")
        message = "There was an error finding all devices"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def get( event, context ):
    conn = connection()
    params = event['pathParameters']
    deviceID = params.get('device_id')

    status_code = 200
    if deviceID is None:
        logger.error("The device ID was not included in request parameters")
        message = "Could not find the Device"
        status_code = 404
        conn.close()

    else:
        try:
            sql = "SELECT * FROM `Device` WHERE `device_id` = %s"
            cursor = conn.cursor()
            cursor.execute( sql, deviceID )
            conn.commit()
            message = cursor.fetchone()
            logger.info("Query results {}".format(message))
        except:
            logger.error("Query for a single device failed")
            message = "There was an error finding the device"
            status_code = 400
        finally:
            conn.close()
    
    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers':{
            "Access-Control-Allow-Origin": "*"
        }
    }


def register(event, context):
    """
    Inserts a new device into the Device database table with a status of 'Pending'.
    :param event: The Lambda event containing a name and section id to be inserted.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    message = "Added new entry to table"
    status_code = 200

    if 'device_id' in obj:
        logger.error('ID specified in Device creation')
        message = "Invalid fields in body of the request"
        status_code = 500
    else:
        try:
            sql = ("INSERT INTO E_Bulletin.Device (`instance_id`, `client_id`, `status`) VALUES (%s,%s,%s)")
            cursor = conn.cursor()
            cursor.execute(sql,
                           (
                               
                                obj['instance_id'],
                                obj['client_id'],
                                "Pending"
                           ))
            conn.commit()
        except:
            logger.error("Error while inserting a new device.")
            message = "Could not create a new device"
            status_code = 400
        finally:
            conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def approve( event, context ):
    """
    Approve a pending device.
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    mqtt_client = boto3.client('iot-data', region_name="us-east-1")
    conn = connection()
    obj = json.loads(event['body'])
    params = event['pathParameters']
    deviceID = params.get('device_id')

    message = ""
    status_code = 200
    error = False

    if ('name' not in obj) or ('section_id' not in obj) or ('client_id' not in obj):
        logger.error("Missing required fields to perform approval")
        message = "Invalid fields in request body"
        status_code = 400
        error = True
        conn.close()

    elif not error:
        try:
            client_id = obj['client_id']
            section_id = obj['section_id']

            topic_name = str(client_id) + "/" + str(section_id) + "/" + str(deviceID)
            sql = "UPDATE `Device` SET `name`= (%s), `section_id` = (%s), `topic_name`=(%s), `status`=(%s) WHERE `device_id` = (%s)"
            cursor = conn.cursor()
            cursor.execute( sql, ( obj['name'], section_id, topic_name,"Approved", deviceID ) )
            conn.commit()
            message = "Successfully approved device - {}".format(obj['name'])
            status_topic = obj['instance_id']
            mqtt_client.publish(
                topic=status_topic,
                qos=0,
                payload=json.dumps({"status":"Approved"})
            )     
        except Exception as e:
            logger.error( "Error when approving this device - %s", str(e) )
            message = "There was an error while trying to approve the device"
            status_code = 400
        finally:
            conn.close()
        
    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def deny( event, context ):
    """
    Deny a pending device. 
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    mqtt_client = boto3.client('iot-data', region_name="us-east-1")
    conn = connection()
    obj = json.loads(event['body'])
    params = event['pathParameters']
    deviceID = params.get('device_id')
    message = ""
    status_code = 200
    error = False

    try:
        status_topic = "" +obj['instance_id']
        sql = "UPDATE `Device` SET `status`=(%s) WHERE `device_id` = (%s)"
        cursor = conn.cursor()
        cursor.execute( sql, ( "Denied", deviceID ) )
        conn.commit()
        message = "Successfully denied device - {}".format(deviceID)
        mqtt_client.publish(
            topic=status_topic,
            qos=0,
            payload=json.dumps({"status":"Denied"})
        )
    except Exception as e:
        logger.error( "Error when denying this device - %s", str(e) )
        message = "There was an error while trying to deny the device request"
        status_code = 400
    finally:
        conn.close()
        
    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def edit(event, context):
    """
    Updates the name of an existing client in the Client database table.
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    params = event['pathParameters']
    deviceID = params.get('device_id')

    message = ""
    status_code = 200
    error = False

    if deviceID == None:
        logger.error("The device ID was not included in request parameters")
        message = "Could not find the Device"
        status_code = 404
        error = True
        conn.close()
        

    if ('name' not in obj) and not error:
        logger.error("Missing required fields to perform update")
        message = "Invalid fields in request body"
        status_code = 400
        error = True
        conn.close()
        

    elif not error:
        try:
            sql = "UPDATE `Device` Set `name` = (%s) WHERE `device_id` = (%s)"
            cursor = conn.cursor()
            cursor.execute(sql, ( obj['name'], deviceID ) )
            conn.commit()
            message = "Successfully updated Device with ID {}".format( params['device_id'] ) 
        except Exception as e:
            logger.error("Error When updating this device - {}".format( str(e) ))
            message = "There was an error while trying to update the device"
            status_code = 400
        finally:
            conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def current_status(event, context):
    """
    Gets the current status of a device in the database.
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    params = event['pathParameters']
    device_id = params.get('device_id')
    status_code = 200
    try:
        sql = "SELECT `status` FROM `Device` WHERE `device_id` = %s"
        cursor = conn.cursor()
        cursor.execute(sql, device_id)
        conn.commit()
        message = cursor.fetchone()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for a single device failed")
        message = "There was an error finding the device"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def set_topic(event, context):
    """
    Sets the topic name of an existing device in the Devices database table.
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    params = event['pathParameters']
    device_id = params.get('device_id')

    status_code = 200

    try:
        sql = "SELECT * FROM `Device` WHERE `device_id` = %s"
        cursor = conn.cursor()
        cursor.execute(sql, device_id)
        conn.commit()
        message = cursor.fetchone()
        client_id = str(message['client_id'])
        section_id = str(message['section_id'])
        topic_name = client_id + "/" + section_id + "/" + device_id
        logger.info(topic_name)

        sql = "UPDATE `Device` Set `topic_name` = (%s) WHERE `device_id` = (%s)"
        cursor.execute(sql, (topic_name, device_id))
        conn.commit()
        message = "Successfully set the topic for Device with ID {}".format(device_id)

    except Exception as e:
        logger.error("Error When updating this device - {}".format(str(e)))
        message = "There was an error while trying to update the device"
        status_code = 400

    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get_topic(event, context):
    """
    Gets the topic name of an existing device in the Devices database table.
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    params = event['pathParameters']
    device_id = params.get('device_id')
    status_code = 200
    try:
        sql = "SELECT `topic_name` FROM `Device` WHERE `device_id` = %s"
        cursor = conn.cursor()
        cursor.execute(sql, device_id)
        conn.commit()
        message = cursor.fetchone()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for a single device failed")
        message = "There was an error finding the device"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get_device_by_instance_id(event, context):
    """
    Gets an existing device in the Devices database table by its instance id.
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    params = event['pathParameters']
    device_id = params.get('instance_id')
    status_code = 200
    try:
        sql = "SELECT * FROM `Device` WHERE `instance_id` = %s"
        cursor = conn.cursor()
        cursor.execute(sql, device_id)
        conn.commit()
        message = cursor.fetchone()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for a single device failed")
        message = "There was an error finding the device"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }

def pending_devices( event, context ):
    """
    This method with retrieve all pending devices across
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 or 400 status code.
    """
    conn = connection()
    status_code = 200

    try:
        sql = "SELECT Client.client_name, Device.* FROM `Device`,`Client` WHERE `status` = %s AND Client.client_id=Device.client_id"
        cursor = conn.cursor()
        cursor.execute( sql, "Pending" )
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for pending devices failed")
        message = "There was an error finding pending device"
        status_code = 400
    finally:
        conn.close()
    
    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers':{
            "Access-Control-Allow-Origin": "*"
        }
    }

def section(event, context):
    """
    Fetches a query of all device by their section id.
    :param event: The Lambda event containing a section id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    section_id = event['pathParameters']['section_id']
    logger.info("Fetching section %s", section_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Device WHERE Device.section_id = %s", section_id)
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def client(event,context):
    """
    Fetches a query of all devices by their client id.
    :param event: The Lambda event containing a client id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    client_id = event['pathParameters']['client_id']
    logger.info("Fetching client %s", client_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Device WHERE Device.client_id = %s", client_id)
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def pending_client(event, context):
    """
    This method with retrieve all pending devices for a client
    :param event: The Lambda event containing the content id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 or 400 status code.
    """
    conn = connection()
    params = event['pathParameters']
    client_id = params.get('client_id')
    status_code = 200

    try:
        sql = "SELECT Client.client_name, Device.* FROM `Device`,`Client` WHERE `status` = %s AND Client.client_id=Device.client_id AND Device.client_id = %s"
        cursor = conn.cursor()
        cursor.execute(sql, ("Pending", client_id))
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for pending content failed")
        message = "There was an error finding pending device"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
