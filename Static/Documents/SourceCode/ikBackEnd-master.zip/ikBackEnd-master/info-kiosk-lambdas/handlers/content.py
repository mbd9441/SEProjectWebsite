"""Handler for all content related lambda requests"""
import sys
import logging
import pymysql
import json
import boto3



logger = logging.getLogger()
logger.setLevel(logging.INFO)


def connection():
    """
    Establishes a connection to mysql in the AWS RDS instance.
    :return: conn -  a mysql connection to the RDS instance
    """
    rds_host = "rdsdbinstance.cy9qzat2q72f.us-east-1.rds.amazonaws.com"
    name = "Admin"
    password = "password"
    db_name = "E_Bulletin"

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, cursorclass=pymysql.cursors.DictCursor)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn


def all(event, context):
    """
    Fetches a query of all content in the Content database table.
    :param event: The Lambda event.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    logger.info("Fetching list of all contents")
    cur = conn.cursor()
    cur.execute("SELECT * from Content")
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get(event, context):
    """
    Fetches a query of a specific content in the Content database table.
    :param event: The Lambda event containing a content id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    content_id = event['pathParameters']['content_id']
    logger.info("Fetching client %s", content_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Content WHERE Content.content_id = %s", content_id)
    conn.commit()
    query = cur.fetchone()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def post(event, context):
    """
    Inserts a new content into the Content database table.
    :param event: The Lambda event containing the
        title, description, content, status, submitter and client id to be inserted.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    cur = conn.cursor()

    try:

        if obj.get('section_id'):
            sql = "INSERT INTO `Content` (`title`, `description`, `content`, `status`, `submitter`, `client_id`, `section_id`) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            cur.execute(
                sql, (
                    obj['title'],
                    obj['description'],
                    obj['content'],
                    obj['status'],
                    obj['submitter'],
                    obj['client_id'],
                    obj['section_id']
                )
            )
            conn.commit()
        else:
            sql = "INSERT INTO `Content` (`title`, `description`, `content`, `status`, `submitter`, `client_id`) VALUES (%s, %s, %s, %s, %s, %s)"
            cur.execute(
                sql, (
                    obj['title'],
                    obj['description'],
                    obj['content'],
                    obj['status'],
                    obj['submitter'],
                    obj['client_id']
                )
            )
            conn.commit()
    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    body = {
        "message": "Added new entry to table"
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def content_request(event, context):
    """
    Inserts a new content into the Content database table with a status of pending and it's device id.
    :param event: The Lambda event containing the
        title, description, content, submitter and client id to be inserted.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    cur = conn.cursor()
    try:
        sql = "INSERT INTO `Content` (`title`, `description`, `content`, `status`, `submitter`, `client_id`, `device_id`, `section_id`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        cur.execute(
            sql, (
                obj['title'],
                obj['description'],
                obj['content'],
                "Pending",
                obj['submitter'],
                obj['client_id'],
                obj['device_id'],
                obj['section_id']
            )
        )
        conn.commit()

    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    body = {
        "message": "Added new content request to table"
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def pending_content(event, context):
    """
    This method with retrieve all pending content across clients
    :param event: The Lambda event containing the content id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 or 400 status code.
    """
    conn = connection()
    status_code = 200

    try:
        sql = "SELECT Content.* FROM `Content` WHERE `status` = %s"
        cursor = conn.cursor()
        cursor.execute(sql, "Pending")
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for pending content failed")
        message = "There was an error finding pending content"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def approve(event, context):
    """
    Approve a pending content.
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    mqtt_client = boto3.client('iot-data', region_name="us-east-1")
    conn = connection()
    params = event['pathParameters']
    content_id = params.get('content_id')
    status_code = 200
    try:
        sql = "UPDATE `Content` SET `status`=(%s) WHERE `content_id` = (%s)"
        cursor = conn.cursor()
        cursor.execute(sql, ("Approved", content_id))
        conn.commit()
        message = "Successfully approved content - {}".format(content_id)
        device = "SELECT `device_id` FROM `Content` WHERE `content_id` = %s"
        cursor.execute(device, (content_id))
        query = cursor.fetchone()
        logger.info(query)
        conn.commit()

        if query['device_id']:
            device_id = query['device_id']
            logger.info(device_id)
            topic = "SELECT `topic_name` FROM `Device` WHERE `device_id` = %s"
            cursor.execute(topic,device_id)
            query = cursor.fetchone()
            conn.commit()
            topic_name = query['topic_name']
            logger.info(topic_name)
            sql = "SELECT * FROM `Device_Content` WHERE `content_id` = %s AND `device_id` = %s"
            cursor.execute(sql, (content_id, device_id))
            query = cursor.fetchall()
            logger.info(query)
            conn.commit()
            print(query)
            print(type(query))
            if not query:
                sql = "INSERT INTO `Device_Content` (`content_id`, `device_id`, `time_published`, `is_active`) VALUES (%s, %s, NOW(), %s)"
                cursor.execute(
                    sql, (
                        content_id,
                        device_id,
                        "1"
                    )
                )
                conn.commit()
            else:
                sql = "UPDATE `Device_Content` Set `is_active` = (%s) WHERE `content_id` = %s AND `device_id` = %s"
                cursor.execute(
                    sql, ("1", content_id, device_id)
                )
                conn.commit()
            mqtt_client.publish(
                topic=topic_name,
                qos=0,
                payload=json.dumps({"status": "Approved new content"})
            )

    except Exception as e:
        logger.error("Error when approving this content - %s", str(e))
        message = "There was an error while trying to approve the content"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def deny(event, context):
    """
    Deny a pending content.
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    params = event['pathParameters']
    content_id = params.get('content_id')
    status_code = 200

    try:
        sql = "UPDATE `Content` SET `status`=(%s) WHERE `content_id` = (%s)"
        cursor = conn.cursor()
        cursor.execute(sql, ("Denied", content_id))
        conn.commit()
        message = "Successfully denied content - {}".format(content_id)
    except Exception as e:
        logger.error("Error when denying this content - %s", str(e))
        message = "There was an error while trying to deny the content request"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def client(event,context):
    """
    Fetches a query of all content by its client id.
    :param event: The Lambda event containing a content id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    client_id = event['pathParameters']['client_id']
    logger.info("Fetching client %s", client_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Content WHERE Content.client_id = %s", client_id)
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def section(event, context):
    """
    Fetches a query of all content by its section id.
    :param event: The Lambda event containing a section id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    section_id = event['pathParameters']['section_id']
    logger.info("Fetching section %s", section_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Content WHERE Content.section_id = %s", section_id)
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def pending_client(event, context):
    """
    This method with retrieve all pending content for a client
    :param event: The Lambda event containing the content id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 or 400 status code.
    """
    conn = connection()
    params = event['pathParameters']
    client_id = params.get('client_id')
    status_code = 200

    try:
        sql = "SELECT Content.* FROM `Content` WHERE `status` = (%s) AND `client_id` = (%s)"
        cursor = conn.cursor()
        cursor.execute(sql, ("Pending", client_id))
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for pending content failed")
        message = "There was an error finding pending content"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def pending_section(event, context):
    """
    This method with retrieve all pending content for a section
    :param event: The Lambda event containing the content id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 or 400 status code.
    """
    conn = connection()
    params = event['pathParameters']
    section_id = params.get('section_id')
    status_code = 200

    try:
        sql = "SELECT Content.* FROM `Content` WHERE `status` = (%s) AND `section_id` = (%s)"
        cursor = conn.cursor()
        cursor.execute(sql, ("Pending", section_id))
        conn.commit()
        message = cursor.fetchall()
        logger.info("Query results {}".format(message))
    except:
        logger.error("Query for pending content failed")
        message = "There was an error finding pending content"
        status_code = 400
    finally:
        conn.close()

    body = {
        "message": message
    }

    return {
        'statusCode': status_code,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
