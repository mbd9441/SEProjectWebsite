"""Handler for all user related lambda requests"""
import logging
import json
import boto3

from datetime import date, datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError("Type %s not serializable" % type(obj))
    

def all(event, context):
    """
    Returns a list of all users stored in the Cognito user pool
    """
    cognitoClient = boto3.client('cognito-idp')
    allUsers = cognitoClient.list_users(UserPoolId='us-east-1_yRtsJkGqc').get('Users')

    if not allUsers:
        allUsers = []
    
    body = {
        "message": allUsers
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def client(event, context):
    """
    Returns a list of all users stored in the Cognito user pool for a given client
    """
    cognitoClient = boto3.client('cognito-idp')
    client_id = event['pathParameters']['client_id']
    allUsers = cognitoClient.list_users(UserPoolId='us-east-1_yRtsJkGqc').get('Users')
    client_users = []

    if not allUsers:
        allUsers = []

    for user in allUsers:
        for attribute in user["Attributes"]:
            if attribute["Name"] == "custom:client_id":
                if attribute["Value"] == client_id:
                    client_users.append(user)
    body = {
        "message": client_users
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def section(event, context):
    """
    Returns a list of all users stored in the Cognito user pool for a given section.
    """
    cognitoClient = boto3.client('cognito-idp')
    section_id = event['pathParameters']['section_id']
    allUsers = cognitoClient.list_users(UserPoolId='us-east-1_yRtsJkGqc').get('Users')
    section_users = []

    if not allUsers:
        allUsers = []

    for user in allUsers:
        for attribute in user["Attributes"]:
            if attribute["Name"] == "custom:section_id":
                if attribute["Value"] == section_id:
                    section_users.append(user)
    body = {
        "message": section_users
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
