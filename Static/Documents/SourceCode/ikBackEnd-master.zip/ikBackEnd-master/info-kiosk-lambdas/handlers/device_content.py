"""Handler for all device content related lambda requests"""
import sys
import logging
import pymysql
import json
import boto3

from datetime import date, datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def connection():
    """
    Establishes a connection to mysql in the AWS RDS instance.
    :return: conn -  a mysql connection to the RDS instance
    """
    rds_host = "rdsdbinstance.cy9qzat2q72f.us-east-1.rds.amazonaws.com"
    name = "Admin"
    password = "password"
    db_name = "E_Bulletin"

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, cursorclass=pymysql.cursors.DictCursor)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError("Type %s not serializable" % type(obj))

def all(event, context):
    """
    Fetches a query of all content in the Device_Content database table.
    :param event: The Lambda event.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    logger.info("Fetching list of all contents")
    cur = conn.cursor()
    cur.execute("SELECT * from Device_Content")
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def push(event, context):
    """
    Pushes content to the database and calls iot publish to alert the device
    :param event: The Lambda event containing the device id, content id, and topic name.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    client = boto3.client('iot-data', region_name="us-east-1")
    conn = connection()
    obj = json.loads(event['body'])
    content_id = obj['content_id']
    device_id = obj['device_id']
    topic_name = obj['topic_name'] # passed in instead of fetched just incase the web app wants to push to multiple
    cur = conn.cursor()
    try:
        sql = "SELECT * FROM `Device_Content` WHERE `content_id` = %s AND `device_id` = %s"
        cur.execute(sql, (content_id, device_id))
        query = cur.fetchall()
        logger.info(query)
        conn.commit()
        print(query)
        print(type(query))
        if not query:
            sql = "INSERT INTO `Device_Content` (`content_id`, `device_id`, `time_published`, `is_active`) VALUES (%s, %s, NOW(), %s)"
            cur.execute(
                sql, (
                    content_id,
                    device_id,
                    "1"
                )
            )
            conn.commit()
        else:
            sql = "UPDATE `Device_Content` Set `is_active` = (%s) WHERE `content_id` = %s AND `device_id` = %s"
            cur.execute(
                sql, ("1", content_id, device_id)
            )
            conn.commit()
    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    body = {
        "message": "Pushed new content to TV"
    }

    client.publish(
        topic=topic_name,
        qos=0,
        payload=json.dumps(body)
    )

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def update_active(event, context):
    """
    Deactivates a content that is pushed to a device in the database table.
    :param event: The Lambda event containing the device id, content id, active status, and topic name.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    client = boto3.client('iot-data', region_name="us-east-1")
    conn = connection()
    obj = json.loads(event['body'])
    content_id = obj['content_id']
    device_id = obj['device_id']
    is_active = obj['is_active']
    topic_name = obj['topic_name']  # passed in instead of fetched just incase the web app wants to push to multiple
    cur = conn.cursor()
    try:
        sql = "UPDATE `Device_Content` Set `is_active` = (%s) WHERE `content_id` = %s AND `device_id` = %s"
        cur.execute(sql, (is_active, content_id, device_id))
        conn.commit()
    except:
        logger.error("SQL update command failed.")
        sys.exit()

    body = {
        "message": "Updated active status in the table"
    }

    client.publish(
        topic=topic_name,
        qos=0,
        payload=json.dumps(body)
    )

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get_active_content(event, context):
    """
    Gets all active content for a single tv
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    device_id = event['pathParameters']['device_id']
    cur = conn.cursor()
    cards = {"Cards": []}
    try:
        sql = "SELECT * FROM `Device_Content` WHERE `device_id` = %s AND `is_active` = %s ORDER BY `time_published`"
        cur.execute(sql, (device_id, "1"))
        query = cur.fetchall()
        logger.info(query)
        conn.commit()
        for item in query:
            card = {}
            content_id = item["content_id"]
            content_sql = "Select * From `Content` WHERE `content_id` = %s"
            cur.execute(content_sql, content_id)
            content = cur.fetchone()
            conn.commit()
            card["Title"] = content["title"]
            card["Description"] = content["description"]
            card["Link"] = content["content"]
            cards["Cards"].append(card)

    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    return {
        'statusCode': 200,
        'body': json.dumps(cards, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get_deployed_content(event, context):
    """
    Gets all deployed content for a single tv
    :param event: The Lambda event containing the device id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    device_id = event['pathParameters']['device_id']
    logger.info("Getting all currently deployed content for device %s", device_id)
    cur = conn.cursor()
    sql = "SELECT Content.*, Device_Content.* FROM `Device_Content`, `Content` WHERE Content.content_id=Device_Content.content_id AND Device_Content.device_id = %s"
    cur.execute(sql, (device_id))
    query = cur.fetchall()
    logger.info(query)
    conn.commit()
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body, default=json_serial),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
