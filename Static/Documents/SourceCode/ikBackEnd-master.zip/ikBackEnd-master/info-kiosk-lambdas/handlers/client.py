"""Handler for all client related lambda requests"""
import sys
import logging
import pymysql
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def connection():
    """
    Establishes a connection to mysql in the AWS RDS instance.
    :return: conn -  a mysql connection to the RDS instance
    """
    rds_host = "rdsdbinstance.cy9qzat2q72f.us-east-1.rds.amazonaws.com"
    name = "Admin"
    password = "password"
    db_name = "E_Bulletin"

    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, cursorclass=pymysql.cursors.DictCursor)
    except:
        logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()

    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
    return conn


def all(event, context):
    """
    Fetches a query of all clients in the Client database table.
    :param event: The Lambda event.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    logger.info("Fetching list of all clients")
    cur = conn.cursor()
    cur.execute("SELECT * from Client")
    conn.commit()
    query = cur.fetchall()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def get(event, context):
    """
    Fetches a query of a specific client in the Client database table.
    :param event: The Lambda event containing a client id.
    :param context: The Lambda context.
    :return: A web response containing the query and a 200 status code.
    """
    conn = connection()
    client_id = event['pathParameters']['client_id']
    logger.info("Fetching client %s", client_id)
    cur = conn.cursor()
    cur.execute("SELECT * from Client WHERE Client.client_id = %s", client_id)
    conn.commit()
    query = cur.fetchone()
    logger.info(query)
    body = {
        "message": query
    }
    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def post(event, context):
    """
    Inserts a new client into the Client database table.
    :param event: The Lambda event containing a client name to be inserted.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    cur = conn.cursor()
    
    try:
        sql = "INSERT INTO `Client` (`client_name`) VALUES (%s)"
        cur.execute(sql, (obj['client_name']))
        conn.commit()
    except:
        logger.error("SQL insert command failed.")
        sys.exit()

    body = {
        "message": "Added new entry to table"
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }


def edit(event, context):
    """
    Updates the name of an existing client in the Client database table.
    :param event: The Lambda event containing the updated client name and the existing client id.
    :param context: The Lambda context.
    :return: A web response containing a confirmation and a 200 status code.
    """
    conn = connection()
    obj = json.loads(event['body'])
    cur = conn.cursor()
    if 'client_id' not in obj or 'client_name' not in obj:
        logger.error("Missing required fields to perform update")
        raise Exception('Missing client id or name in request')

    try:
        sql = "UPDATE `Client` Set `client_name` = (%s) WHERE `client_id` = (%s)"
        cur.execute(sql, (obj['client_name'], obj['client_id']))
        conn.commit()
    except:
        logger.error("Encountered error with sql update")
        sys.exit()

    body = {
        "message": ("Successfully updated %s in Client table", obj['client_id'])
    }

    return {
        'statusCode': 200,
        'body': json.dumps(body),
        'headers': {
            "Access-Control-Allow-Origin": "*"
        }
    }
