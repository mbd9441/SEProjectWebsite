"""Tests for section.py"""
import json

from unittest import TestCase, mock, main

import handlers.device as device


FAKE_DEVICE_ID = "fake_id"
FAKE_DEVICE_NAME = "fake_name"
FAKE_GET_ALL = {}
FAKE_GET_EVENT = {'pathParameters': {'device_id':FAKE_DEVICE_ID}}
FAKE_CLIENT_EVENT = {'pathParameters': {'client_id':FAKE_DEVICE_ID}}
FAKE_SECTION_EVENT = {'pathParameters': {'section_id':FAKE_DEVICE_ID}}
INVALID_GET_EVENT = {'pathParameters': {}, 'body':'{}'}
FAKE_POST_EVENT = {'body': '{"name":"fake_device","section_id":"fake_id"}'}
FAKE_POST_EVENT_ID = {'body': '{"device_id":"fake_id"}'}
FAKE_REGISTER_EVENT = {'body': json.dumps({
                                # "section_id":"fake_id",
                                # "topic_name":"faketopic",
                                "instance_id":"fake_id",
                                "client_id":"fake_client",})}
                                # "status":"fake_status"})}
FAKE_REGISTER_EVENT_ID = {'body': '{"device_id":"fake_id"}'}
FAKE_EDIT_EVENT = { 
    'pathParameters': { "device_id": FAKE_DEVICE_ID },
    'body': '{"name": "fake_name" }'
}
NO_BODY_EDIT_EVENT = {
    'pathParameters': { "device_id": FAKE_DEVICE_ID },
    'body': '{}'
}
FAKE_CONTEXT = "context"

FAKE_APPROVE_EVENT = {'body': '{ "name":"fake_name","section_id": "fake_id", "client_id": "fake_id","instance_id":"fake_id" }',
                        'pathParameters': {"device_id": FAKE_DEVICE_ID}
    }

FAKE_DENY_EVENT  = {
    'body': json.dumps({
                        "instance_id":"fake_id"
            }),
            
            'pathParameters': {"device_id": FAKE_DEVICE_ID}
    }


class TestClient(TestCase):

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_all(self,mock_pymysql):
        """ Test to for retrieving all sections from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device.all(FAKE_GET_ALL, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
    
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_all_with_mysql_exception(self,mock_pymysql):
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.all(FAKE_GET_ALL, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body':'{"message": "There was an error finding all devices"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, result )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get(self, mock_pymysql):
        """ Test to for retrieving a single client from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = device.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body':'{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
    
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_with_mysql_exception(self,mock_pymysql):
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        print("This is the RESULT - ",result)
        expected = {
            'statusCode': 400,
            'body':'{"message": "There was an error finding the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, result )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_without_id(self, mock_pymysql):
        """ Test to for invalid register request"""
        actual = device.get(INVALID_GET_EVENT, FAKE_CONTEXT )
        expected = {
            'statusCode': 404,
            'body': '{"message": "Could not find the Device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    def test_broken_sql(self):
        """ Test for broken sql connection"""
        self.assertRaises(SystemExit, device.connection)


    
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_register(self, mock_pymysql):
        """ Test to for inserting device into database"""
        result = device.register( FAKE_REGISTER_EVENT, FAKE_CONTEXT )
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new entry to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_register_with_id(self, mock_pymysql):
        """ Test to for invalid register request"""
        actual = device.register( FAKE_REGISTER_EVENT_ID, FAKE_CONTEXT )
        expected = {
            'statusCode': 500,
            'body': '{"message": "Invalid fields in body of the request"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_failed_device_insert(self, mock_pymysql):
        """ Test to for invalid sql insert device"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        actual = device.register(FAKE_REGISTER_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "Could not create a new device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_edit(self,mock_pymysql):
        """ Test to for editing a client in database"""
        result = device.edit(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully updated Device with ID fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_edit_without_id(self, mock_pymysql):
        """ Test to for invalid register request"""
        actual = device.edit(INVALID_GET_EVENT, FAKE_CONTEXT )
        expected = {
            'statusCode': 404,
            'body': '{"message": "Could not find the Device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_edit_without_fields(self, mock_pymysql):
        """ Test to for invalid register request"""
        actual = device.edit( NO_BODY_EDIT_EVENT, FAKE_CONTEXT )
        expected = {
            'statusCode': 400,
            'body': '{"message": "Invalid fields in request body"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )
    
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_edit_with_mysql_exception(self, mock_pymysql):
        """ Test edit mysql exception """
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.edit(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body':'{"message": "There was an error while trying to update the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, result )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_current_status(self, mock_pymysql):
        """ Test to for retrieving a device's status from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = device.current_status(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_current_status_with_mysql_exception(self, mock_pymysql):
        """ Test status mysql exception """
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.current_status(FAKE_GET_EVENT, FAKE_CONTEXT)
        print("This is the RESULT - ", result)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error finding the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_topic(self, mock_pymysql):
        """ Test to for retrieving a device's topic from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = device.get_topic(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_topic_with_mysql_exception(self, mock_pymysql):
        """ Test get topic mysql exception """
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.get_topic(FAKE_GET_EVENT, FAKE_CONTEXT)
        print("This is the RESULT - ", result)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error finding the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_set_topic(self, mock_pymysql):
        """ Test to for setting a device's topic in database"""
        result = device.set_topic(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully set the topic for Device with ID fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_set_topic_with_mysql_exception(self, mock_pymysql):
        """ Test set topic mysql exception """
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.set_topic(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error while trying to update the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_device_by_instance_id(self, mock_pymysql):
        """ Test to for retrieving a device by its instance id"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = device.get_device_by_instance_id(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_get_device_by_instance_id_with_mysql_exception(self, mock_pymysql):
        """ Test get by instance mysql exception """
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = device.get_device_by_instance_id(FAKE_GET_EVENT, FAKE_CONTEXT)
        print("This is the RESULT - ", result)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error finding the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        
    @mock.patch('handlers.device.boto3', autospec=True)
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_approve(self, mock_pymysql,mock_boto):
        """ Test to for retrieving a device by its instance id"""
        result = device.approve(FAKE_APPROVE_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully approved device - fake_name"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.boto3', autospec=True)
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_approve_with_missing_fields(self, mock_pymysql,mock_boto):
        """ Test to for approving a device by its instance id"""
        result = device.approve(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "Invalid fields in request body"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.boto3', autospec=True)
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_failed_device_approval(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert device"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        actual = device.approve(FAKE_APPROVE_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error while trying to approve the device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )
    
    @mock.patch('handlers.device.boto3', autospec=True)
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_deny(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert device"""
        actual = device.deny(FAKE_DENY_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully denied device - fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )
    
    @mock.patch('handlers.device.boto3', autospec=True)
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_failed_device_denial(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert device"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        actual = device.deny(FAKE_DENY_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error while trying to deny the device request"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_pending_devices(self,mock_pymysql):
        """ Test to for retrieving all sections from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device.pending_devices(FAKE_GET_ALL, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
    
    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_pending_devices_with_mysql_exception(self,mock_pymysql):
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        all = device.pending_devices(FAKE_GET_EVENT, FAKE_CONTEXT)
        client = device.pending_client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body':'{"message": "There was an error finding pending device"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, all)
        self.assertEqual(expected, client)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_client(self, mock_pymysql):
        """ Test to for retrieving all devices from database by client"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device.client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_section(self, mock_pymysql):
        """ Test to for retrieving all devices from database by section"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device.section(FAKE_SECTION_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device.pymysql', autospec=True)
    def test_pending_client(self, mock_pymysql):
        """ Test to for retrieving a pending devices by client id"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device.pending_client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)


if __name__ == '__main__':
    main()
