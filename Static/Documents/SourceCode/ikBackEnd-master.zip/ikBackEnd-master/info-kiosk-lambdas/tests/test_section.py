"""Tests for section.py"""
from unittest import TestCase, mock, main

import handlers.section as section

FAKE_ID = "fake_id"
FAKE_CLIENT_NAME = "fake_name"
FAKE_GET_EVENT = {'pathParameters': {'section_id':FAKE_ID}}
FAKE_POST_EVENT = {'body': '{"section_name":"fake_section","client_id":"fake_id"}'}
FAKE_POST_EVENT_ID = {'body': '{"section_id":"fake_id"}'}
FAKE_REGISTER_EVENT = {'body': '{"name":"fake_section","section_id":"fake_id"}'}
FIND_BY_CLIENTID_EVENT = {'pathParameters': {"client_id":FAKE_ID}}
FAKE_CONTEXT = "context"


class TestClient(TestCase):

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_all(self,mock_pymysql):
        """ Test to for retrieving all sections from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = section.all(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_get(self, mock_pymysql):
        """ Test to for retrieving a single client from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = section.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body':'{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_get_with_mysql_exception(self,mock_pymysql):
        """ Test for mysql exception handling"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = section.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body':'{"message": "Sorry an error has occured while trying to retrieve the sections"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, result )

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_get_without_id(self, mock_pymysql):
        """ Test to for invalid register request"""
        FAKE_GET_EVENT['pathParameters'] = {}
        actual = section.get( FAKE_GET_EVENT, FAKE_CONTEXT )
        print(actual)
        expected = {
            'statusCode': 404,
            'body': '{"message": "Could not find the Section"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_post(self, mock_pymysql):
        """ Test to for inserting section into database"""
        result = section.post(FAKE_POST_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new entry to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()
    
    

    # @mock.patch('handlers.section.pymysql', autospec=True)
    # def test_post_with_id(self, mock_pymysql):
    #     """ Test to for invalid section post request"""
    #     self.assertRaises(Exception, section.post, FAKE_POST_EVENT_ID, FAKE_CONTEXT)

    def test_broken_sql(self):
        """ Test for broken sql connection"""
        self.assertRaises(SystemExit, section.connection)

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_failed_insert(self, mock_pymysql):
        """ Test to for invalid sql insert section"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, section.post, FAKE_POST_EVENT, FAKE_CONTEXT)
    
    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_find_section_by_client_id(self, mock_pymysql):
        """ Test to for retrieving all sections from database by client id"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = section.findByClientId(FIND_BY_CLIENTID_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body':'{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_find_section_by_client_id_with_mysql_exception(self,mock_pymysql):
        """ Test for mysql exception handling"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        result = section.findByClientId(FIND_BY_CLIENTID_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body':'{"message": "Sorry an error has occured while trying to retrieve the sections"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, result )

    @mock.patch('handlers.section.pymysql', autospec=True)
    def test_find_section_by_client_id_without_id(self, mock_pymysql):
        """ Test to for invalid register request"""
        FIND_BY_CLIENTID_EVENT['pathParameters'] = {}
        actual = section.findByClientId( FIND_BY_CLIENTID_EVENT, FAKE_CONTEXT )
        print(actual)
        expected = {
            'statusCode': 404,
            'body': '{"message": "Could not find the Section"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual( expected, actual )


if __name__ == '__main__':
    main()
