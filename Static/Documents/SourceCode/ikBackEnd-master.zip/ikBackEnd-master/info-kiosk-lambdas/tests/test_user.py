"""Tests for user.py"""
import json
import handlers.user as user

from datetime import datetime
from unittest import TestCase, mock, main

FAKE_CLIENT_ID = "client"
FAKE_SECTION_ID = "section"
FAKE_CLIENT_EVENT = {'pathParameters': {'client_id': FAKE_CLIENT_ID}}
FAKE_SECTION_EVENT = {'pathParameters': {'section_id': FAKE_SECTION_ID}}
FAKE_USER_DICT = {'Users':[{'Attributes':[
        {
          'Name':'custom:client_id',
          'Value':FAKE_CLIENT_ID
        },
        {
            'Name':'custom:section_id',
            'Value':FAKE_SECTION_ID
        }]}]}


class TestUser(TestCase):

    def test_serial(self):
        """ Test for json serial"""
        time = datetime.now()
        expected = time.isoformat()
        result = user.json_serial(time)
        self.assertEqual(expected, result)

    def test_failed_serial(self):
        """ Test to for invalid json serial"""
        time = "failplease"
        self.assertRaises(TypeError, user.json_serial, time)

    @mock.patch('handlers.user.boto3', autospec=True)
    def test_all(self, mock_boto):
        """ Test to for retrieving all users from cognito"""
        test_body = {'Users':'hello'}
        mock_boto.client.return_value.list_users.return_value = test_body
        result = user.all({}, {})
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.user.boto3', autospec=True)
    def test_no_users(self, mock_boto):
        """ Test for if there are no users in cognito"""
        test_body = {}
        mock_boto.client.return_value.list_users.return_value = test_body

        all = user.all({}, {})
        client = user.client(FAKE_CLIENT_EVENT, {})
        section = user.section(FAKE_SECTION_EVENT, {})

        expected = {
            'statusCode': 200,
            'body': '{"message": []}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, all)
        self.assertEqual(expected, client)
        self.assertEqual(expected, section)

    @mock.patch('handlers.user.boto3', autospec=True)
    def test_client(self, mock_boto):
        """Test to get all users by client id """
        test_body = FAKE_USER_DICT
        mock_boto.client.return_value.list_users.return_value = test_body
        result = user.client(FAKE_CLIENT_EVENT, {})
        body = {
            "message": FAKE_USER_DICT['Users']
        }
        expected = {
            'statusCode': 200,
            'body': json.dumps(body),
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.user.boto3', autospec=True)
    def test_section(self, mock_boto):
        """Test to get all users by client id """
        test_body = FAKE_USER_DICT
        mock_boto.client.return_value.list_users.return_value = test_body
        result = user.section(FAKE_SECTION_EVENT, {})
        body = {
            "message": FAKE_USER_DICT['Users']
        }
        expected = {
            'statusCode': 200,
            'body': json.dumps(body),
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
