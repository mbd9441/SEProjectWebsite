"""Tests for content.py"""
from unittest import TestCase, mock, main

import handlers.content as content

FAKE_CLIENT_ID = "fake_id"
FAKE_CLIENT_NAME = "fake_name"
FAKE_GET_EVENT = {'pathParameters': {'content_id':FAKE_CLIENT_ID}}
FAKE_CLIENT_EVENT = {'pathParameters': {'client_id':FAKE_CLIENT_ID}}
FAKE_SECTION_EVENT = {'pathParameters': {'section_id':FAKE_CLIENT_ID}}
FAKE_POST_EVENT = {'body': '{"title":"fake_title","description":"fake_description","content":"fake_content","status":"fake_status","submitter":"fake_submitter","client_id":"fake_id", "device_id":"fake_device", "section_id":"fake_section"}'}
FAKE_POST_NO_SECTION_EVENT = {'body': '{"title":"fake_title","description":"fake_description","content":"fake_content","status":"fake_status","submitter":"fake_submitter","client_id":"fake_id", "device_id":"fake_device"}'}
FAKE_POST_EVENT_ID = {'body': '{"content_id":"fake_id"}'}
FAKE_CONTEXT = "context"


class TestClient(TestCase):

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_all(self,mock_pymysql):
        """ Test to for retrieving all contents from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.all(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_get(self, mock_pymysql):
        """ Test to for retrieving a single content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = content.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_post(self, mock_pymysql):
        """ Test to for inserting content into database"""
        result = content.post(FAKE_POST_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new entry to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_post_without_section(self, mock_pymysql):
        """ Test to for inserting content into database without section"""
        result = content.post(FAKE_POST_NO_SECTION_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new entry to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()
    # @mock.patch('handlers.content.pymysql', autospec=True)
    # def test_post_with_id(self, mock_pymysql):
    #     """ Test to for invalid content post request"""
    #     self.assertRaises(Exception, content.post, FAKE_POST_EVENT_ID, FAKE_CONTEXT)

    def test_broken_sql(self):
        """ Test for broken sql connection"""
        self.assertRaises(SystemExit, content.connection)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_failed_insert(self, mock_pymysql):
        """ Test to for invalid sql insert content"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, content.post, FAKE_POST_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_content_request(self, mock_pymysql):
        """ Test to for requesting content to the system"""
        result = content.content_request(FAKE_POST_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new content request to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_failed_request(self, mock_pymysql):
        """ Test to for invalid sql request content"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, content.content_request, FAKE_POST_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.content.boto3', autospec=True)
    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_approve(self, mock_pymysql, mock_boto):
        """ Test to for approving a content request"""
        result = content.approve(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully approved content - fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.boto3', autospec=True)
    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_empty_query(self, mock_pymysql, mock_boto):
        """ Test for device content alreay existing"""
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = ()
        result = content.approve(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully approved content - fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.boto3', autospec=True)
    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_failed_content_approval(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert content"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        actual = content.approve(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error while trying to approve the content"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, actual)

    @mock.patch('handlers.content.boto3', autospec=True)
    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_deny(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert content"""
        actual = content.deny(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Successfully denied content - fake_id"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, actual)

    @mock.patch('handlers.content.boto3', autospec=True)
    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_failed_content_denial(self, mock_pymysql, mock_boto):
        """ Test to for invalid sql insert content"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        actual = content.deny(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error while trying to deny the content request"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, actual)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_pending_content(self, mock_pymysql):
        """ Test to for retrieving all pending content"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.pending_content(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_pending_content_with_mysql_exception(self, mock_pymysql):
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        all = content.pending_content(FAKE_GET_EVENT, FAKE_CONTEXT)
        client = content.pending_client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        section = content.pending_section(FAKE_SECTION_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 400,
            'body': '{"message": "There was an error finding pending content"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, all)
        self.assertEqual(expected, client)
        self.assertEqual(expected, section)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_pending_client(self, mock_pymysql):
        """ Test to for retrieving a single content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.pending_client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_pending_section(self, mock_pymysql):
        """ Test to for retrieving a single content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.pending_section(FAKE_SECTION_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_section(self, mock_pymysql):
        """ Test to for retrieving a single content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.section(FAKE_SECTION_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.content.pymysql', autospec=True)
    def test_client(self, mock_pymysql):
        """ Test to for retrieving a single content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = content.client(FAKE_CLIENT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)


if __name__ == '__main__':
    main()
