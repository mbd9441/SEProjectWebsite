"""Tests for client.py"""
from unittest import TestCase, mock, main

import handlers.client as client

FAKE_CLIENT_ID = "fake_id"
FAKE_CLIENT_NAME = "fake_name"
FAKE_GET_EVENT = {'pathParameters': {'client_id':FAKE_CLIENT_ID}}
FAKE_POST_EVENT = {'body': '{"client_name":"fake_name"}'}
FAKE_POST_EVENT_ID = {'body': '{"client_id":"fake_id"}'}
FAKE_EDIT_EVENT = {'body': '{"client_name":"fake_name", "client_id":"fake_id"}'}
FAKE_CONTEXT = "context"


class TestClient(TestCase):

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_all(self,mock_pymysql):
        """ Test to for retrieving all clients from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = client.all(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_get(self, mock_pymysql):
        """ Test to for retrieving a single client from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_body
        result = client.get(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_post(self, mock_pymysql):
        """ Test to for adding a client to database"""
        result = client.post(FAKE_POST_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Added new entry to table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    # @mock.patch('handlers.client.pymysql', autospec=True)
    # def test_post_with_id(self, mock_pymysql):
    #     """ Test to for invalid client post request"""
    #     self.assertRaises(Exception, client.post, FAKE_POST_EVENT_ID, FAKE_CONTEXT)

    def test_broken_sql(self):
        """ Test for broken sql connection"""
        self.assertRaises(SystemExit, client.connection)

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_failed_insert(self, mock_pymysql):
        """ Test to for invalid sql insert client"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, client.post, FAKE_POST_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_edit(self,mock_pymysql):
        """ Test to for editing a client in database"""
        result = client.edit(FAKE_EDIT_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": ["Successfully updated %s in Client table", "fake_id"]}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_edit_without_fields(self, mock_pymysql):
        """ Test to for invalid edit client request"""
        self.assertRaises(Exception, client.edit, FAKE_POST_EVENT_ID, FAKE_CONTEXT)

    @mock.patch('handlers.client.pymysql', autospec=True)
    def test_failed_update(self, mock_pymysql):
        """ Test to for invalid sql update client"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, client.edit, FAKE_EDIT_EVENT, FAKE_CONTEXT)


if __name__ == '__main__':
    main()
