"""Tests for device_content.py"""
import json

from datetime import datetime
from unittest import TestCase, mock, main

import handlers.device_content as device_content


FAKE_DEVICE_ID = "fake_id"
FAKE_DEVICE_NAME = "fake_name"
FAKE_GET_ALL = {}
FAKE_GET_EVENT = {'pathParameters': {'device_id':FAKE_DEVICE_ID}}
INVALID_GET_EVENT = {'pathParameters': {}, 'body':'{}'}
FAKE_POST_EVENT = {'body': '{"name":"fake_device","section_id":"fake_id"}'}
FAKE_POST_EVENT_ID = {'body': '{"device_id":"fake_id"}'}
PUSH_DICT = {
    "content_id": "fake_id",
    "topic_name": "faketopic",
    "device_id": "fake_id",
    "is_active": "0"
}
FAKE_PUSH_EVENT = {'body': json.dumps(PUSH_DICT)}
FAKE_CONTEXT = "context"


class TestDeviceContent(TestCase):

    def test_broken_sql(self):
        """ Test for broken sql connection"""
        self.assertRaises(SystemExit, device_content.connection)

    def test_serial(self):
        """ Test for json serial"""
        time = datetime.now()
        expected = time.isoformat()
        result = device_content.json_serial(time)
        self.assertEqual(expected, result)

    def test_failed_serial(self):
        """ Test to for invalid json serial"""
        time = "failplease"
        self.assertRaises(TypeError, device_content.json_serial, time)

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_all(self,mock_pymysql):
        """ Test to for retrieving all device content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device_content.all(FAKE_GET_ALL, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device_content.boto3', autospec=True)
    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_push(self,mock_pymysql, mock_boto):
        """ Test to for inserting pushing content to a tv"""
        result = device_content.push(FAKE_PUSH_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Pushed new content to TV"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.device_content.boto3', autospec=True)
    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_empty_query(self,mock_pymysql, mock_boto):
        """ Test for device content alreay existing"""
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = ()
        result = device_content.push(FAKE_PUSH_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Pushed new content to TV"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_failed_device_content_insert(self, mock_pymysql):
        """ Test to for invalid sql insert device"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, device_content.push, FAKE_PUSH_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.device_content.boto3', autospec=True)
    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_update_active(self,mock_pymysql, mock_boto):
        """Test to update the status of a devices content"""
        result = device_content.update_active(FAKE_PUSH_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "Updated active status in the table"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)
        mock_pymysql.connect.return_value.cursor.return_value.execute.assert_called()

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_failed_device_content_update(self, mock_pymysql):
        """ Test to for invalid sql update device"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, device_content.update_active, FAKE_PUSH_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_get_active_content(self, mock_pymysql):
        """ Test to for retrieving all active content for a tv from database"""
        test_all = [{"content_id":"fake_id"}, {"content_id":"fake_id"},{"content_id":"fake_id"},{"content_id":"fake_id"},{"content_id":"fake_id"}]
        test_one = {"title":"hello", "description":"hello", "content":"hello"}
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_all
        mock_pymysql.connect.return_value.cursor.return_value.fetchone.return_value = test_one
        response_body = {"Cards":
                             [{"Title": "hello", "Description": "hello", "Link": "hello"},
                              {"Title": "hello", "Description": "hello", "Link": "hello"},
                              {"Title": "hello","Description": "hello", "Link": "hello"},
                              {"Title": "hello", "Description": "hello","Link": "hello"},
                              {"Title": "hello", "Description": "hello", "Link": "hello"}
                              ]
                         }
        result = device_content.get_active_content(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': json.dumps(response_body),
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_get_with_mysql_exception(self,mock_pymysql):
        """ Test to for invalid sql select device content"""
        mock_pymysql.connect.return_value.cursor.return_value.execute.side_effect = Exception
        self.assertRaises(SystemExit, device_content.get_active_content, FAKE_GET_EVENT, FAKE_CONTEXT)

    @mock.patch('handlers.device_content.pymysql', autospec=True)
    def test_get_deployed(self, mock_pymysql):
        """ Test to for retrieving all device content from database"""
        test_body = "hello"
        mock_pymysql.connect.return_value.cursor.return_value.fetchall.return_value = test_body
        result = device_content.get_deployed_content(FAKE_GET_EVENT, FAKE_CONTEXT)
        expected = {
            'statusCode': 200,
            'body': '{"message": "hello"}',
            'headers': {
                "Access-Control-Allow-Origin": "*"
            }
        }
        self.assertEqual(expected, result)

if __name__ == '__main__':
    main()
